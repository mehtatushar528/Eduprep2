const fs = require('fs');
const lines = fs.readFileSync('C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\previous_year_papers\\code.html', 'utf8').split('\n');
for (let i = 398; i < Math.min(lines.length, 435); i++) {
  console.log((i+1) + ': ' + lines[i]);
}
