const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

// 1. login_registration/code.html
const loginPath = path.join(base, 'login_registration/code.html');
let loginTxt = fs.readFileSync(loginPath, 'utf8');
const loginTarget = '      <div class="flex items-center gap-3">\n        <a href="../index.html" class="text-xs';
const loginReplacement = `      <!-- Public Navigation (Permanent across all pages) -->
      <nav aria-label="Public Navigation" class="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm font-semibold text-on-surface-variant">
        <a href="../index.html#home" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">Home</a>
        <a href="../index.html#features" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">Features</a>
        <a href="../index.html#about" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">About</a>
      </nav>

      <div class="flex items-center gap-3">
        <a href="../index.html" class="text-xs`;
loginTxt = loginTxt.replace(loginTarget, loginReplacement);
fs.writeFileSync(loginPath, loginTxt, 'utf8');
console.log('Updated login_registration');

// 2. affiliated_college_selection/code.html
const affPath = path.join(base, 'affiliated_college_selection/code.html');
let affTxt = fs.readFileSync(affPath, 'utf8');
const affTarget = `    <div class="flex items-center gap-2">
      <span class="text-xs font-semibold text-on-surface-variant">Step 2 of 4</span>`;
const affReplacement = `    <!-- Public Navigation (Permanent across all pages) -->
    <nav aria-label="Public Navigation" class="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm font-semibold text-on-surface-variant">
      <a href="../index.html#home" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">Home</a>
      <a href="../index.html#features" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">Features</a>
      <a href="../index.html#about" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">About</a>
    </nav>

    <div class="flex items-center gap-2">
      <span class="text-xs font-semibold text-on-surface-variant">Step 2 of 4</span>`;
affTxt = affTxt.replace(affTarget, affReplacement);
fs.writeFileSync(affPath, affTxt, 'utf8');
console.log('Updated affiliated_college_selection');
