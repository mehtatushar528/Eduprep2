const fs = require('fs');
const path = require('path');

// Common mojibake sequences when UTF-8 bytes are decoded as Windows-1252 / ISO-8859-1:
// UTF-8 E2 80 A2 (•) -> â€¢
// UTF-8 E2 80 93 (–) -> â€“
// UTF-8 E2 80 94 (—) -> â€”
// UTF-8 E2 80 99 (’) -> â€™
// UTF-8 E2 80 9C (“) -> â€œ
// UTF-8 E2 80 9D (”) -> â€\x9d
// UTF-8 E2 80 98 (‘) -> â€˜
// UTF-8 EF BF BD () -> \uFFFD
// Also \u00E2\u20AC\u00A2, \u00E2\u20AC\u201C, etc.

const patterns = [
  { name: 'â€¢ (bullet)', regex: /\u00E2\u20AC\u00A2/g, fix: '•' },
  { name: 'â€“ (en-dash)', regex: /\u00E2\u20AC\u2013/g, fix: '–' },
  { name: 'â€” (em-dash)', regex: /\u00E2\u20AC\u2014/g, fix: '—' },
  { name: 'â€™ (right apostrophe)', regex: /\u00E2\u20AC\u2122/g, fix: "'" },
  { name: 'â€˜ (left quote)', regex: /\u00E2\u20AC\u02DC/g, fix: "'" },
  { name: 'â€œ (left double quote)', regex: /\u00E2\u20AC\u0153/g, fix: '"' },
  { name: 'â€ (right double quote)', regex: /\u00E2\u20AC\u009D/g, fix: '"' },
  { name: 'Replacement character \uFFFD', regex: /\uFFFD/g, fix: '•' }
];

function scanAndReport(dir) {
  const files = fs.readdirSync(dir);
  for (const f of files) {
    const full = path.join(dir, f);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) {
      if (f !== 'node_modules' && f !== '.git' && f !== 'scratch' && f !== '.system_generated') {
        scanAndReport(full);
      }
    } else if (f.endsWith('.html') || f.endsWith('.js') || f.endsWith('.json')) {
      const buf = fs.readFileSync(full);
      const str = buf.toString('utf8');
      
      const found = [];
      for (const p of patterns) {
        const m = str.match(p.regex);
        if (m) found.push(`${p.name} (${m.length})`);
      }
      
      // Also look for literal "â€"
      const lit = str.match(/â€/g);
      if (lit && found.length === 0) {
        found.push(`literal â€ (${lit.length})`);
      }
      
      if (found.length > 0) {
        console.log(`${full}: ${found.join(', ')}`);
      }
    }
  }
}

scanAndReport('C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep');
