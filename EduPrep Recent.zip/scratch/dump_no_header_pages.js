const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

['questions_practice/code.html', 'subject_details/code.html', 'subject_details_os/code.html', 'study_ai_assistant/code.html', '404.html'].forEach(f => {
  const full = path.join(base, f);
  const txt = fs.readFileSync(full, 'utf8');
  console.log(`\n=== TOP OF ${f} ===`);
  const lines = txt.split('\n');
  const bodyIdx = lines.findIndex(l => l.includes('<body'));
  console.log(lines.slice(bodyIdx >= 0 ? bodyIdx : 0, (bodyIdx >= 0 ? bodyIdx : 0) + 20).join('\n'));
});
