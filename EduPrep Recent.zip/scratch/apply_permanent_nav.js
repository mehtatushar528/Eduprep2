const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

const publicNavSnippet = `      <!-- Public Navigation (Permanent across all pages) -->
      <nav aria-label="Public Navigation" class="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm font-semibold text-on-surface-variant">
        <a href="../index.html#home" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">Home</a>
        <a href="../index.html#features" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">Features</a>
        <a href="../index.html#about" class="px-2.5 sm:px-3.5 py-1.5 rounded-xl hover:bg-surface-container hover:text-on-surface transition-colors">About</a>
      </nav>`;

const corePages = [
  'home_dashboard/code.html',
  'previous_year_papers/code.html',
  'academic_setup/code.html',
  'activities/code.html',
  'user_profile_progress/code.html',
  'mcq_practice_exam/code.html',
  'revision_flashcards/code.html',
  'resources_dashboard/code.html',
  'student_opportunities/code.html',
  'admin_panel/code.html',
  'affiliated_college_selection/code.html',
  'ai_tutor_personality_setup/code.html',
  'academic_setup_updated_flow/code.html',
  'login_registration/code.html'
];

let updatedCount = 0;

corePages.forEach(p => {
  const full = path.join(base, p);
  if (!fs.existsSync(full)) {
    console.log('Skipping missing:', p);
    return;
  }
  let txt = fs.readFileSync(full, 'utf8');
  if (txt.includes('aria-label="Public Navigation"')) {
    console.log('Already has Public Navigation:', p);
    return;
  }

  // Find header
  const headerMatch = txt.match(/<header[^>]*>([\s\S]*?)<\/header>/i);
  if (!headerMatch) {
    console.log('No <header> in:', p);
    return;
  }

  // Each header has Row 1 with two main child blocks: left div and right div
  // In typical EduPrep pages:
  // <div class="flex justify-between items-center ..."> (or flex ... justify-between)
  //   <div class="flex items-center gap-...">...</div>
  //   [WE INSERT PUBLIC NAV HERE]
  //   <div class="flex items-center gap-...">...</div>
  // </div>

  // Let's locate the first outer div inside <header>
  const headerContent = headerMatch[1];
  
  // Find first closing </div> of the first flex items-center group
  // We can insert right after the first child </div> of the header's container
  // Let's use regex to find: (first group inside header row)
  // Look for the logo/left block closing </div>
  
  let modified = false;

  // Pattern A: standard pages with left block ending before right controls
  // e.g. </div>\s*<div class="flex items-center gap-
  // Replace the first occurrence of `</div>\s*<div class="flex items-center gap-`
  // with `</div>\n\n${publicNavSnippet}\n\n      <div class="flex items-center gap-`
  
  const patternA = /(<\/div>\s*)(<div class="(?:flex items-center gap-|flex gap-1 h-1.5|hidden sm:flex))/i;
  const matchA = headerContent.match(patternA);
  
  if (matchA) {
    const newHeaderContent = headerContent.replace(patternA, `$1\n${publicNavSnippet}\n\n      $2`);
    txt = txt.replace(headerContent, newHeaderContent);
    fs.writeFileSync(full, txt, 'utf8');
    console.log('Successfully inserted Public Navigation in:', p);
    updatedCount++;
    modified = true;
  } else {
    console.log('Could not match pattern in:', p);
  }
});

console.log(`\nUpdated ${updatedCount} pages.`);
