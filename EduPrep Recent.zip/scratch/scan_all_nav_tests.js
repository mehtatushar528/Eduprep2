const fs = require('fs');
const path = require('path');
const testsDir = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\tests';

fs.readdirSync(testsDir).forEach(f => {
  if (f.endsWith('.test.js')) {
    const full = path.join(testsDir, f);
    const lines = fs.readFileSync(full, 'utf8').split('\n');
    lines.forEach((l, idx) => {
      if (l.includes('Navigation') || l.includes('navigation') || l.includes('Public Navigation') || l.includes('Student Navigation')) {
        console.log(`${f}:${idx+1} -> ${l.trim()}`);
      }
    });
  }
});
