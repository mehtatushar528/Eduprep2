const fs = require("fs");
const p = "./EduPrep/EduPrep/home_dashboard/code.html";
const content = fs.readFileSync(p, "utf8");
const inlineScriptRegex = /<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/gi;
let match;
let idx = 0;
while ((match = inlineScriptRegex.exec(content)) !== null) {
  idx++;
  if (idx === 2) {
    const lines = match[1].split("\n");
    for (let i = 715; i < 765; i++) {
      console.log(`${i}: ${lines[i - 1]}`);
    }
  }
}
