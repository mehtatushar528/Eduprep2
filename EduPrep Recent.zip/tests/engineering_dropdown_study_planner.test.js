const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

// Simulate DOM & LocalStorage environment
class LocalStorageMock {
  constructor() { this.store = {}; }
  getItem(k) { return this.store[k] || null; }
  setItem(k, v) { this.store[k] = String(v); }
  removeItem(k) { delete this.store[k]; }
  clear() { this.store = {}; }
}

global.window = global;
global.localStorage = new LocalStorageMock();

// Load shared data scripts
eval(fs.readFileSync('EduPrep/EduPrep/shared/eduprep_data.js', 'utf8'));
eval(fs.readFileSync('EduPrep/EduPrep/shared/eduprep_chapters_data.js', 'utf8'));

// Mock toast & UI helpers
EduPrep.showToast = () => {};

test('Study Planner Dropdown Suite - Engineering, Medical, Commerce, Arts', async (t) => {
  // Setup simulated DOM for academic_setup/code.html
  function setupDOM() {
    const selectMock = (id) => ({
      id,
      options: [],
      selectedIndex: 0,
      value: '',
      innerHTML: '',
      dataset: {}
    });

    const inputMock = (id) => ({
      id,
      value: '',
      dataset: {}
    });

    const buttonMock = (id) => ({
      id,
      disabled: false,
      classList: {
        classes: new Set(),
        add(c) { this.classes.add(c); },
        remove(c) { this.classes.delete(c); },
        contains(c) { return this.classes.has(c); }
      }
    });

    const dom = {
      planStreamSelect: selectMock('planStreamSelect'),
      planSubjectSelect: selectMock('planSubjectSelect'),
      planChapterSelect: selectMock('planChapterSelect'),
      planGoalInput: inputMock('planGoalInput'),
      planDateInput: inputMock('planDateInput'),
      planDurationSelect: selectMock('planDurationSelect'),
      planPrioritySelect: selectMock('planPrioritySelect'),
      btnCreatePlan: buttonMock('btnCreatePlan'),
      statTotalPlans: { textContent: '0' },
      statUpcomingPlans: { textContent: '0' },
      statOverduePlans: { textContent: '0' },
      statCompletedPlans: { textContent: '0' },
      studyPlansGridContainer: { innerHTML: '' },
      plannerSemBadge: { textContent: '' },
      plannerHeroTitle: { textContent: '' }
    };

    global.document = {
      getElementById(id) { return dom[id] || null; },
      addEventListener() {}
    };

    return dom;
  }

  setupDOM();

  function parseHtmlOptions(html) {
    const regex = /<option\s+value="([^"]*)"(?:\s+data-code="([^"]*)")?>([^<]*)<\/option>/g;
    const matches = [];
    let match;
    while ((match = regex.exec(html)) !== null) {
      matches.push({ value: match[1], code: match[2] || '', text: match[3] });
    }
    return matches;
  }

  // Extract functions from academic_setup/code.html
  const codeHtml = fs.readFileSync('EduPrep/EduPrep/academic_setup/code.html', 'utf8');
  const scriptMatch = codeHtml.match(/<script>([\s\S]*?)<\/script>\s*<\/body>/);
  assert.ok(scriptMatch, 'script in code.html must be found');
  eval(scriptMatch[1]);

  await t.test('TEST 1: Select Engineering with a Semester 8 profile - shows full engineering subject catalogue', () => {
    setupDOM();
    EduPrep.setSemester(8);
    const state = EduPrep.getState();
    assert.equal(state.academic.semester, 8, 'Active semester should be 8');

    populateSubjectDropdown('engineering');
    const subjSelect = document.getElementById('planSubjectSelect');
    const options = parseHtmlOptions(subjSelect.innerHTML);

    assert.ok(options.length >= 25, `Should contain at least 25 subjects, found ${options.length}`);
    
    // Crucial: Must contain subjects from Semesters 1, 2, 3, 4, 5, 6, 7, 8
    const requiredSubjects = [
      'Engineering Mathematics',
      'Data Structures',
      'Operating Systems',
      'Computer Networks',
      'Database Management Systems',
      'Artificial Intelligence',
      'Machine Learning',
      'Cloud Computing'
    ];

    requiredSubjects.forEach(name => {
      const found = options.some(o => o.text === name);
      assert.ok(found, `Semester 8 student should see "${name}" in Engineering subject dropdown`);
    });
  });

  await t.test('TEST 2: Select Operating Systems - displays all 6 Operating Systems chapters with semester labels', () => {
    setupDOM();
    populateChapterDropdown('Operating Systems');
    const chSelect = document.getElementById('planChapterSelect');
    const options = parseHtmlOptions(chSelect.innerHTML);

    assert.equal(options.length, 6, 'Operating Systems should have exactly 6 chapters');
    options.forEach(opt => {
      assert.ok(opt.value.startsWith('ch_os_s4_'), `Chapter id must be valid catalog id, got: ${opt.value}`);
      assert.ok(opt.text.includes('Semester 4'), `Chapter label must include semester, got: ${opt.text}`);
      assert.ok(opt.text.includes('Unit '), `Chapter label must include Unit prefix, got: ${opt.text}`);
    });
    assert.equal(document.getElementById('btnCreatePlan').disabled, false, 'Save button must be enabled');
  });

  await t.test('TEST 3: Select Computer Networks - displays only Computer Networks chapters', () => {
    setupDOM();
    populateChapterDropdown('Computer Networks');
    const chSelect = document.getElementById('planChapterSelect');
    const options = parseHtmlOptions(chSelect.innerHTML);

    assert.equal(options.length, 6, 'Computer Networks should have 6 chapters');
    options.forEach(opt => {
      assert.ok(opt.value.startsWith('ch_computer_networks_s4_'), `Chapter id must start with ch_computer_networks_s4_, got: ${opt.value}`);
      assert.ok(opt.text.includes('Semester 4'), `Chapter label must indicate Semester 4, got: ${opt.text}`);
    });
  });

  await t.test('TEST 4: Select Cloud Computing - displays all 5 Cloud Computing units with Semester 8 label', () => {
    setupDOM();
    populateChapterDropdown('Cloud Computing');
    const chSelect = document.getElementById('planChapterSelect');
    const options = parseHtmlOptions(chSelect.innerHTML);

    assert.equal(options.length, 5, 'Cloud Computing should have 5 chapters');
    options.forEach(opt => {
      assert.ok(opt.value.startsWith('ch_cloud_computing_s8_'), `Chapter id must start with ch_cloud_computing_s8_, got: ${opt.value}`);
      assert.ok(opt.text.includes('Semester 8'), `Chapter label must indicate Semester 8, got: ${opt.text}`);
    });
  });

  await t.test('TEST 5: Switch to Medical - displays full Medical subject list and first subject chapters', () => {
    setupDOM();
    populateSubjectDropdown('medical');
    const subjSelect = document.getElementById('planSubjectSelect');
    const options = parseHtmlOptions(subjSelect.innerHTML);

    assert.equal(options.length, 15, 'Medical should have 15 subjects');
    assert.equal(options[0].text, 'Anatomy', 'First medical subject should be Anatomy');

    const chSelect = document.getElementById('planChapterSelect');
    const chOptions = parseHtmlOptions(chSelect.innerHTML);
    assert.ok(chOptions.length > 0, 'Anatomy chapters should be populated immediately');
    assert.ok(chOptions[0].value.startsWith('ch_med_anatomy_'), 'Chapter id must belong to anatomy');
  });

  await t.test('TEST 6: Switch to Commerce and Arts - both display their full catalogues correctly', () => {
    setupDOM();
    populateSubjectDropdown('commerce');
    let options = parseHtmlOptions(document.getElementById('planSubjectSelect').innerHTML);
    assert.equal(options.length, 15, 'Commerce should have 15 subjects');
    assert.equal(options[0].text, 'Financial Accounting', 'First commerce subject should be Financial Accounting');

    populateSubjectDropdown('arts');
    options = parseHtmlOptions(document.getElementById('planSubjectSelect').innerHTML);
    assert.equal(options.length, 15, 'Arts should have 15 subjects');
    assert.equal(options[0].text, 'English Literature', 'First arts subject should be English Literature');
  });

  await t.test('TEST 7: Changing subjects multiple times updates chapter options immediately without stale entries', () => {
    setupDOM();
    populateSubjectDropdown('engineering');

    // Switch to Operating Systems
    onSubjectChanged('Operating Systems');
    let chOptions = parseHtmlOptions(document.getElementById('planChapterSelect').innerHTML);
    assert.ok(chOptions.every(o => o.value.startsWith('ch_os_')), 'All chapters must be OS');

    // Switch to Computer Networks
    onSubjectChanged('Computer Networks');
    chOptions = parseHtmlOptions(document.getElementById('planChapterSelect').innerHTML);
    assert.ok(chOptions.every(o => o.value.startsWith('ch_computer_networks_')), 'All chapters must be CN');

    // Switch to Cloud Computing
    onSubjectChanged('Cloud Computing');
    chOptions = parseHtmlOptions(document.getElementById('planChapterSelect').innerHTML);
    assert.ok(chOptions.every(o => o.value.startsWith('ch_cloud_computing_')), 'All chapters must be Cloud');
  });

  await t.test('TEST 8: Save a study target from another semester (Sem 8 student saving Sem 4 Operating Systems unit)', () => {
    const dom = setupDOM();
    localStorage.clear();
    EduPrep.setSemester(8);

    dom.planStreamSelect.value = 'engineering';
    populateSubjectDropdown('engineering');

    // Select Operating Systems
    onSubjectChanged('Operating Systems');
    const chSelect = dom.planChapterSelect;
    const chOptions = parseHtmlOptions(chSelect.innerHTML);

    dom.planSubjectSelect.value = 'Operating Systems';
    dom.planSubjectSelect.options = [{ value: 'Operating Systems', dataset: { code: 'CSC401' } }];
    dom.planSubjectSelect.selectedIndex = 0;

    dom.planChapterSelect.value = chOptions[0].value;
    dom.planChapterSelect.options = [{ value: chOptions[0].value, textContent: chOptions[0].text }];
    dom.planChapterSelect.selectedIndex = 0;

    dom.planGoalInput.value = 'Complete OS System Calls assignment and notes';
    dom.planDateInput.value = '2026-11-15';
    dom.planDurationSelect.value = '2.5 Hours';
    dom.planPrioritySelect.value = 'High';

    handleCreatePlan({ preventDefault: () => {} });

    const plans = loadPlans();
    assert.equal(plans.length, 1, 'Should have saved 1 plan');
    const p = plans[0];
    assert.equal(p.stream, 'engineering');
    assert.equal(p.subject, 'Operating Systems');
    assert.equal(p.subjectCode, 'CSC401');
    assert.equal(p.chapterId, 'ch_os_s4_1');
    assert.ok(p.chapterTitle.includes('OS Structures, System Calls'));
    assert.equal(p.goal, 'Complete OS System Calls assignment and notes');
    assert.equal(p.dueDate, '2026-11-15');
    assert.equal(p.priority, 'High');
    assert.equal(p.completed, false);
  });

  await t.test('TEST 9: Refresh / persistence - saved plans remain intact across calls', () => {
    const plansBefore = loadPlans();
    assert.equal(plansBefore.length, 1, 'Plan should still exist in localStorage');

    // Simulate page re-init
    initSubjectAndChapterDropdowns();
    const plansAfter = loadPlans();
    assert.equal(plansAfter.length, 1, 'Plan must persist after re-initializing dropdowns');
    assert.equal(plansAfter[0].subject, 'Operating Systems');
  });

  await t.test('TEST 10: Subject without mapped units shows informative placeholder and disables save', () => {
    const dom = setupDOM();
    populateChapterDropdown('Major Project');
    const chSelect = dom.planChapterSelect;
    const options = parseHtmlOptions(chSelect.innerHTML);

    assert.equal(options.length, 1, 'Should show exactly 1 placeholder option');
    assert.equal(options[0].value, '', 'Placeholder value must be empty');
    assert.ok(options[0].text.includes('No verified units available for this subject yet'), `Text must state no verified units available, got: ${options[0].text}`);
    assert.equal(dom.btnCreatePlan.disabled, true, 'Save button must be disabled');

    // Attempting to submit must trigger early return and not save
    let toastMsg = '';
    EduPrep.showToast = (msg) => { toastMsg = msg; };
    dom.planSubjectSelect.value = 'Major Project';
    dom.planSubjectSelect.options = [{ value: 'Major Project', dataset: { code: 'CSP801' } }];
    dom.planSubjectSelect.selectedIndex = 0;
    dom.planChapterSelect.value = '';
    dom.planGoalInput.value = 'Some unmapped task';

    const countBefore = loadPlans().length;
    handleCreatePlan({ preventDefault: () => {} });
    const countAfter = loadPlans().length;

    assert.equal(countAfter, countBefore, 'Plan count must not change when chapter is unavailable');
    assert.ok(toastMsg.includes('No verified units available for this subject yet'), `Toast must warn user, got: ${toastMsg}`);
  });
});
