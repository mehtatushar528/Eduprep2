const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
console.log("Scanning root:", root);

function getHtmlFiles(dir) {
  let files = [];
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, item.name);
    if (item.isDirectory()) {
      if (item.name === "node_modules" || item.name === ".git") continue;
      files = files.concat(getHtmlFiles(full));
    } else if (item.name.endsWith(".html")) {
      files.push(full);
    }
  }
  return files;
}

const htmlFiles = getHtmlFiles(root);
console.log("Found " + htmlFiles.length + " HTML files.");

let issues = 0;

for (const htmlFile of htmlFiles) {
  const content = fs.readFileSync(htmlFile, "utf8");
  const rel = path.relative(root, htmlFile);
  const dir = path.dirname(htmlFile);

  // Check script src
  const scriptSrcRegex = /<script\s+[^>]*src=["']([^"']+)["']/gi;
  let match;
  while ((match = scriptSrcRegex.exec(content)) !== null) {
    const src = match[1];
    if (src.startsWith("http://") || src.startsWith("https://") || src.startsWith("//")) continue;
    // local file
    const cleanSrc = src.split("?")[0].split("#")[0];
    let resolved;
    if (cleanSrc.startsWith("/")) {
      resolved = path.join(root, "EduPrep", cleanSrc);
      if (!fs.existsSync(resolved)) {
        resolved = path.join(root, cleanSrc);
      }
    } else {
      resolved = path.resolve(dir, cleanSrc);
    }
    // Also check if it's served virtually by serve.js like /shared/env_config.js or /shared/vendor/supabase.js
    const isVirtual = cleanSrc.endsWith("/shared/env_config.js") || cleanSrc.endsWith("/shared/vendor/supabase.js") || cleanSrc.endsWith("/shared/supabase.umd.js");
    if (!fs.existsSync(resolved) && !isVirtual) {
      console.log(`[BROKEN SCRIPT SRC] In ${rel}: src="${src}" (looked at ${resolved})`);
      issues++;
    }
  }

  // Check link href (stylesheets, icons)
  const linkHrefRegex = /<link\s+[^>]*href=["']([^"']+)["'][^>]*>/gi;
  while ((match = linkHrefRegex.exec(content)) !== null) {
    const fullTag = match[0];
    if (!fullTag.includes("stylesheet") && !fullTag.includes("icon")) continue;
    const href = match[1];
    if (href.startsWith("http://") || href.startsWith("https://") || href.startsWith("//") || href.startsWith("data:")) continue;
    const cleanHref = href.split("?")[0].split("#")[0];
    let resolved;
    if (cleanHref.startsWith("/")) {
      resolved = path.join(root, "EduPrep", cleanHref);
      if (!fs.existsSync(resolved)) {
        resolved = path.join(root, cleanHref);
      }
    } else {
      resolved = path.resolve(dir, cleanHref);
    }
    if (!fs.existsSync(resolved)) {
      console.log(`[BROKEN LINK HREF] In ${rel}: href="${href}" (looked at ${resolved})`);
      issues++;
    }
  }

  // Check inline scripts
  const inlineScriptRegex = /<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/gi;
  let scriptIdx = 0;
  while ((match = inlineScriptRegex.exec(content)) !== null) {
    scriptIdx++;
    const code = match[1].trim();
    if (!code) continue;
    try {
      new vm.Script(code, { filename: `${rel}#script${scriptIdx}` });
    } catch (err) {
      console.log(`[INLINE SCRIPT SYNTAX ERROR] In ${rel} (script #${scriptIdx}): ${err.message}`);
      issues++;
    }
  }
}

console.log("Scan finished. Total issues found: " + issues);
