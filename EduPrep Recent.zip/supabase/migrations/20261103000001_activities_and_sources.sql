-- ============================================================================
-- EduPrep — Migration: Activities & Automated Source Integration
-- Migration ID: 20261103000001_activities_and_sources.sql
-- Supports real-time hackathons, scholarships, internships, workshops, and
-- student opportunities with Gemini AI classification and verified sources.
-- ============================================================================

-- 1. Enhance public.opportunities with detailed temporal and verification metadata
ALTER TABLE public.opportunities
  DROP CONSTRAINT IF EXISTS opportunities_opportunity_type_check;

ALTER TABLE public.opportunities
  ADD COLUMN IF NOT EXISTS announcement_date DATE,
  ADD COLUMN IF NOT EXISTS registration_start DATE,
  ADD COLUMN IF NOT EXISTS registration_deadline DATE,
  ADD COLUMN IF NOT EXISTS event_start DATE,
  ADD COLUMN IF NOT EXISTS event_end DATE,
  ADD COLUMN IF NOT EXISTS required_skills TEXT[] DEFAULT '{}'::TEXT[],
  ADD COLUMN IF NOT EXISTS required_documents TEXT[] DEFAULT '{}'::TEXT[],
  ADD COLUMN IF NOT EXISTS stipend TEXT,
  ADD COLUMN IF NOT EXISTS prize_details TEXT,
  ADD COLUMN IF NOT EXISTS source_url TEXT,
  ADD COLUMN IF NOT EXISTS source_id TEXT,
  ADD COLUMN IF NOT EXISTS ai_metadata JSONB DEFAULT '{}'::JSONB,
  ADD COLUMN IF NOT EXISTS missing_fields TEXT[] DEFAULT '{}'::TEXT[],
  ADD COLUMN IF NOT EXISTS uncertain_fields TEXT[] DEFAULT '{}'::TEXT[],
  ADD COLUMN IF NOT EXISTS is_sample BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS content_fingerprint TEXT,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- 2. Configurable Opportunity Sources
CREATE TABLE IF NOT EXISTS public.activity_sources (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  category TEXT NOT NULL,
  source_type TEXT NOT NULL DEFAULT 'portal' CHECK (source_type IN ('api', 'rss', 'portal', 'official_board')),
  access_method TEXT NOT NULL DEFAULT 'http_get',
  is_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  refresh_interval_minutes INT NOT NULL DEFAULT 360,
  last_successful_refresh TIMESTAMPTZ,
  last_failed_refresh TIMESTAMPTZ,
  error_message TEXT,
  reliability_score NUMERIC(3, 2) DEFAULT 1.00,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Scheduled Refresh and Verification Logs
CREATE TABLE IF NOT EXISTS public.activity_refresh_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  discovered_count INT DEFAULT 0,
  updated_count INT DEFAULT 0,
  rejected_count INT DEFAULT 0,
  failed_sources_count INT DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'completed', 'failed')),
  summary JSONB DEFAULT '{}'::JSONB
);

-- 4. Performance Indexes for Querying & Deadlines
CREATE INDEX IF NOT EXISTS idx_opportunities_opp_type ON public.opportunities(opportunity_type);
CREATE INDEX IF NOT EXISTS idx_opportunities_reg_deadline ON public.opportunities(registration_deadline);
CREATE INDEX IF NOT EXISTS idx_opportunities_event_start ON public.opportunities(event_start);
CREATE INDEX IF NOT EXISTS idx_opportunities_verification ON public.opportunities(verification_status);
CREATE INDEX IF NOT EXISTS idx_opportunities_source_id ON public.opportunities(source_id);
CREATE INDEX IF NOT EXISTS idx_activity_sources_enabled ON public.activity_sources(is_enabled);
CREATE INDEX IF NOT EXISTS idx_activity_refresh_logs_started ON public.activity_refresh_logs(started_at DESC);

-- 5. RLS Policies for Activity Sources and Logs
ALTER TABLE public.activity_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_refresh_logs ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'activity_sources' AND policyname = 'Read enabled activity sources'
  ) THEN
    CREATE POLICY "Read enabled activity sources" ON public.activity_sources
      FOR SELECT USING (is_enabled = TRUE);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'activity_refresh_logs' AND policyname = 'Read refresh logs'
  ) THEN
    CREATE POLICY "Read refresh logs" ON public.activity_refresh_logs
      FOR SELECT USING (TRUE);
  END IF;
END $$;
