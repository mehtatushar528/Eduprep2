const fs = require('fs');
const assert = require('assert');
const indexHtml = fs.readFileSync('C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\index.html', 'utf8');

const checks = [
  ['id=academic-streams', indexHtml.includes('id="academic-streams"')],
  ['Choose Your Academic Stream', indexHtml.includes('Choose Your Academic Stream')],
  ['Explore study resources', indexHtml.includes('Explore study resources tailored to your academic field.')],
  ['streamCardMatches.length === 4', (indexHtml.match(/class="[^"]*stream-card[^"]*"/g) || []).length === 4],
  ['Engineering', indexHtml.includes('Engineering')],
  ['Medical', indexHtml.includes('Medical')],
  ['Arts', indexHtml.includes('Arts')],
  ['Commerce', indexHtml.includes('Commerce')],
  ['Eng subtitle', indexHtml.includes('Engineering degrees, technical subjects, and semester preparation.')],
  ['Med subtitle', indexHtml.includes('Medical studies, health sciences, and academic revision.')],
  ['Arts subtitle', indexHtml.includes('Arts, humanities, languages, and creative studies.')],
  ['Com subtitle', indexHtml.includes('Accounting, finance, economics, and business studies.')],
  ['Law degrees false', indexHtml.includes('Law degrees') === false],
  ['Management studies false', indexHtml.includes('Management studies') === false],
  ['quickUniversity false', indexHtml.includes('id="quickUniversity"') === false],
  ['Full Wizard false', indexHtml.includes('Full Wizard') === false]
];

checks.forEach(([name, res]) => console.log(name + ': ' + res));