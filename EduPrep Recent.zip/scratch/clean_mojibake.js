const fs = require('fs');
const path = require('path');

const replacements = [
  // 3-byte mojibake
  { from: /â€¢/g, to: '•' },
  { from: /â€“/g, to: '–' },
  { from: /â€”/g, to: '—' },
  { from: /â€™/g, to: "'" },
  { from: /â€˜/g, to: "'" },
  { from: /â€œ/g, to: '"' },
  { from: /â€\u009d/g, to: '"' },
  { from: /â€/g, to: '"' },
  { from: /â‚¹/g, to: '₹' },
  { from: /â†’/g, to: '→' },
  { from: /â‰ˆ/g, to: '≈' },
  { from: /âˆ©/g, to: '∩' },
  { from: /â‰¥/g, to: '≥' },
  { from: /â‰¤/g, to: '≤' },
  { from: /â€¹/g, to: '‹' },
  { from: /â€º/g, to: '›' },
  
  // Specific corrupted sequences observed in code:
  // e.g. "1NFâ–BCNF" or "1NF\uFFFDBCNF" or "1NF?"BCNF" -> "1NF–BCNF"
  { from: /1NF[^\w\s]+BCNF/g, to: '1NF–BCNF' },
  // "2022â€"2024" or "2022\uFFFD2024" or "2022?"2024" -> "2022–2024"
  { from: /2022[^\w\s]+2024/g, to: '2022–2024' },
  // "1â€“8" or "1?"8" -> "1–8"
  { from: /1[^\w\s]+8\)/g, to: '1–8)' },
  // "Semester [0-9] â€” " -> "Semester $1 — "
  { from: /Semester (\d+) [^\w\s]+ /g, to: 'Semester $1 — ' }
];

let totalFixed = 0;
let filesModified = 0;

function cleanDir(dir) {
  const files = fs.readdirSync(dir);
  for (const f of files) {
    const full = path.join(dir, f);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) {
      if (f !== 'node_modules' && f !== '.git' && f !== 'scratch' && f !== '.system_generated') {
        cleanDir(full);
      }
    } else if (f.endsWith('.html') || f.endsWith('.js') || f.endsWith('.json')) {
      let content = fs.readFileSync(full, 'utf8');
      let changed = false;
      let fileFixCount = 0;

      for (const r of replacements) {
        const matches = content.match(r.from);
        if (matches) {
          content = content.replace(r.from, r.to);
          fileFixCount += matches.length;
          changed = true;
        }
      }

      if (changed) {
        fs.writeFileSync(full, content, 'utf8');
        console.log(`Cleaned ${fileFixCount} artifacts in: ${path.relative('C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep', full)}`);
        totalFixed += fileFixCount;
        filesModified++;
      }
    }
  }
}

cleanDir('C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep');
console.log(`\nDONE: Fixed ${totalFixed} encoding artifacts across ${filesModified} files.`);
