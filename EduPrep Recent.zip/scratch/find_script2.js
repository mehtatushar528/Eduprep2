const fs = require("fs");
const p = "./EduPrep/EduPrep/home_dashboard/code.html";
const content = fs.readFileSync(p, "utf8");
const inlineScriptRegex = /<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/gi;
let match;
let idx = 0;
while ((match = inlineScriptRegex.exec(content)) !== null) {
  idx++;
  console.log(`=== Script #${idx} === (char index ${match.index})`);
  const lines = match[1].split("\n");
  lines.slice(0, 30).forEach((l, i) => console.log(`${i+1}: ${l}`));
  if (lines.length > 30) {
    console.log(`... and ${lines.length - 30} more lines`);
  }
}
