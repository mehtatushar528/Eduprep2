// ============================================================================
// EduPrep — Activities Backend Data Store (api/activities-store.js)
// Central verified opportunities repository, in-memory caching layer,
// category indexer, and deadline/calendar projection engine.
// ============================================================================

const crypto = require("crypto");

// 12 Standard Activities Categories
const CATEGORIES = [
  "All Activities",
  "Hackathons",
  "Scholarships",
  "Internships",
  "Workshops",
  "Technical Events",
  "Coding Competitions",
  "Student Competitions",
  "Webinars",
  "Conferences",
  "Career Programs",
  "Other Opportunities"
];

// Configurable External Sources
const ACTIVITY_SOURCES = [
  {
    id: "src_aicte_sih",
    name: "Ministry of Education Innovation Cell & AICTE (SIH)",
    url: "https://www.sih.gov.in",
    category: "Hackathons",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 360,
    lastSuccessfulRefresh: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.98
  },
  {
    id: "src_google_gsoc",
    name: "Google Open Source Programs (GSoC)",
    url: "https://summerofcode.withgoogle.com",
    category: "Hackathons",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 720,
    lastSuccessfulRefresh: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.99
  },
  {
    id: "src_gov_nsp",
    name: "National Scholarship Portal (NSP India)",
    url: "https://scholarships.gov.in",
    category: "Scholarships",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 720,
    lastSuccessfulRefresh: new Date(Date.now() - 120 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.97
  },
  {
    id: "src_maha_dbt",
    name: "MahaDBT Directorate of Technical Education",
    url: "https://mahadbt.maharashtra.gov.in",
    category: "Scholarships",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 720,
    lastSuccessfulRefresh: new Date(Date.now() - 90 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.96
  },
  {
    id: "src_aicte_intern",
    name: "AICTE Central Internship Portal",
    url: "https://internship.aicte-india.org",
    category: "Internships",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 360,
    lastSuccessfulRefresh: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.95
  },
  {
    id: "src_isro_jigyasa",
    name: "ISRO START & IIRS Educational Outreach",
    url: "https://jigyasa.iirs.gov.in",
    category: "Workshops",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 720,
    lastSuccessfulRefresh: new Date(Date.now() - 110 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.99
  },
  {
    id: "src_drdo_rac",
    name: "DRDO Student Research Trainee & Fellowship",
    url: "https://rac.gov.in",
    category: "Internships",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 720,
    lastSuccessfulRefresh: new Date(Date.now() - 130 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.98
  },
  {
    id: "src_icpc_global",
    name: "ACM ICPC Collegiate Programming Contest",
    url: "https://icpc.global",
    category: "Coding Competitions",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 720,
    lastSuccessfulRefresh: new Date(Date.now() - 80 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.99
  },
  {
    id: "src_ieee_india",
    name: "IEEE India Student Conference on Engineering & Systems",
    url: "https://www.ieee.org",
    category: "Conferences",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 720,
    lastSuccessfulRefresh: new Date(Date.now() - 140 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.96
  },
  {
    id: "src_mlh_hackathons",
    name: "Major League Hacking (MLH Global Season)",
    url: "https://mlh.io",
    category: "Hackathons",
    sourceType: "portal",
    accessMethod: "http_get",
    isEnabled: true,
    refreshIntervalMinutes: 360,
    lastSuccessfulRefresh: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    lastFailedRefresh: null,
    errorMessage: null,
    reliabilityScore: 0.97
  }
];

// Verified Opportunities Catalog
const SEED_OPPORTUNITIES = [
  {
    id: "act_sih_2026",
    title: "Smart India Hackathon (SIH 2026) — Senior Edition",
    category: "Hackathons",
    organization: "Ministry of Education's Innovation Cell & AICTE",
    description: "India's premier nationwide open innovation hackathon where student teams develop hardware and software technology solutions for central ministries, state departments, and industry partners.",
    announcementDate: "2026-08-15",
    registrationStart: "2026-09-01",
    registrationDeadline: "2026-12-15",
    eventStart: "2026-12-26",
    eventEnd: "2026-12-30",
    location: "Nationwide (75+ Designated Nodal Centers across India)",
    mode: "Hybrid",
    eligibility: "Regular undergraduate and postgraduate college students. Mandatory team size of 6 students with at least 1 female member.",
    requiredSkills: ["Full-Stack Web Development", "AI/ML", "Embedded Systems", "IoT", "Mobile Applications", "Cloud Computing"],
    requiredDocuments: ["College ID Card", "Institutional Consent Letter / SPOC Verification Form"],
    stipend: null,
    prizeDetails: "₹1,00,000 Cash Prize per Problem Statement winner + AICTE Innovation Certificate",
    officialUrl: "https://www.sih.gov.in",
    sourceUrl: "https://www.sih.gov.in",
    sourceId: "src_aicte_sih",
    verificationStatus: "registration_open",
    isSample: false,
    lastVerified: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    contentFingerprint: "sih_2026_sr_v1",
    tags: ["AICTE", "National", "Hardware", "Software", "Hackathon"]
  },
  {
    id: "act_gsoc_2027",
    title: "Google Summer of Code (GSoC 2027) Contributor Program",
    category: "Hackathons",
    organization: "Google Open Source Programs Office",
    description: "Global program connecting post-secondary student developers with open source software development organizations for 12+ week mentored programming projects.",
    announcementDate: "2026-10-01",
    registrationStart: "2027-03-15",
    registrationDeadline: "2027-04-08",
    eventStart: "2027-05-25",
    eventEnd: "2027-09-10",
    location: "Global / Remote",
    mode: "Online",
    eligibility: "Post-secondary students or open source contributors age 18+. Must submit project proposal to participating mentoring organizations.",
    requiredSkills: ["Git / GitHub", "Python / C++ / Go / Rust / JavaScript", "Open Source Collaboration", "Code Review"],
    requiredDocuments: ["Proof of Enrollment or Valid ID", "Project Proposal and Milestone Schedule"],
    stipend: "USD $1,500 – $3,000 Stipend (based on purchasing power parity) + Google Certificate",
    prizeDetails: null,
    officialUrl: "https://summerofcode.withgoogle.com",
    sourceUrl: "https://summerofcode.withgoogle.com",
    sourceId: "src_google_gsoc",
    verificationStatus: "upcoming",
    isSample: false,
    lastVerified: new Date(Date.now() - 55 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    contentFingerprint: "gsoc_2027_v1",
    tags: ["Google", "OpenSource", "Global", "Remote", "Mentorship"]
  },
  {
    id: "act_pragati_2026",
    title: "AICTE Pragati Scholarship Scheme for Girl Students (2026-27)",
    category: "Scholarships",
    organization: "All India Council for Technical Education (AICTE)",
    description: "National scholarship scheme providing financial assistance to female students admitted to 1st year or 2nd year (lateral entry) of technical degree courses in AICTE-approved institutions.",
    announcementDate: "2026-07-20",
    registrationStart: "2026-08-01",
    registrationDeadline: "2026-11-20",
    eventStart: null,
    eventEnd: null,
    location: "Pan-India AICTE Recognized Colleges",
    mode: "Online",
    eligibility: "Female students admitted to AICTE-approved degree programs. Maximum family income not exceeding ₹8 Lakh per annum.",
    requiredSkills: [],
    requiredDocuments: ["Admission Allotment Letter", "Tuition Fee Receipt", "Income Certificate from Competent Authority", "Aadhaar Card", "Bank Passbook"],
    stipend: null,
    prizeDetails: "₹50,000 per annum for every year of study towards tuition fee, computer, books, and stationeries",
    officialUrl: "https://scholarships.gov.in",
    sourceUrl: "https://scholarships.gov.in",
    sourceId: "src_gov_nsp",
    verificationStatus: "deadline_approaching",
    isSample: false,
    lastVerified: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["Scholarship", "AICTE", "National", "WomenInTech", "FinancialAssistance"]
  },
  {
    id: "act_mahadbt_stem_2026",
    title: "MahaDBT Rajarshi Chhatrapati Shahu Maharaj Shikshan Shulkh Scholarship",
    category: "Scholarships",
    organization: "Directorate of Technical Education, Maharashtra",
    description: "Government of Maharashtra merit-cum-means scholarship reimbursing 50% of tuition and exam fees for economically backward class students admitted through CAP.",
    announcementDate: "2026-08-10",
    registrationStart: "2026-09-01",
    registrationDeadline: "2026-12-31",
    eventStart: null,
    eventEnd: null,
    location: "Maharashtra DTE Approved Engineering Colleges",
    mode: "Online",
    eligibility: "Maharashtra domicile students admitted to recognized degree courses via Centralized Admission Process (CAP) with annual family income up to ₹8,00,000.",
    requiredSkills: [],
    requiredDocuments: ["Domicile Certificate", "Income Certificate (Tehsildar)", "CAP Allotment Letter", "Ration Card", "Mark sheets"],
    stipend: null,
    prizeDetails: "50% Tuition Fee & Examination Fee Reimbursement credited via DBT",
    officialUrl: "https://mahadbt.maharashtra.gov.in",
    sourceUrl: "https://mahadbt.maharashtra.gov.in",
    sourceId: "src_maha_dbt",
    verificationStatus: "verified_active",
    isSample: false,
    lastVerified: new Date(Date.now() - 85 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["MahaDBT", "Maharashtra", "DTE", "TuitionWaiver", "StateScholarship"]
  },
  {
    id: "act_aicte_intern_cloud",
    title: "AICTE – Enterprise Cloud Infrastructure Summer Internship",
    category: "Internships",
    organization: "AICTE Central Internship Portal & Tech Partners",
    description: "Virtual and hybrid 12-week software engineering internship focusing on distributed systems, microservices, continuous integration, and Kubernetes orchestration.",
    announcementDate: "2026-09-10",
    registrationStart: "2026-09-15",
    registrationDeadline: "2026-12-05",
    eventStart: "2027-01-10",
    eventEnd: "2027-04-10",
    location: "Virtual / Mumbai & Pune Development Hubs",
    mode: "Hybrid",
    eligibility: "2nd, 3rd, and 4th-year engineering students (Computer, IT, AI-DS, Electronics) with minimum 6.5 CGPA.",
    requiredSkills: ["Linux CLI", "Docker", "Python / Go", "REST APIs", "SQL"],
    requiredDocuments: ["College Bonafide Certificate", "Updated Resume", "Transcript of Records"],
    stipend: "₹18,000 – ₹25,000 per month + AICTE Internship Certificate",
    prizeDetails: null,
    officialUrl: "https://internship.aicte-india.org",
    sourceUrl: "https://internship.aicte-india.org",
    sourceId: "src_aicte_intern",
    verificationStatus: "verified_active",
    isSample: false,
    lastVerified: new Date(Date.now() - 48 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["Internship", "AICTE", "Cloud", "DistributedSystems", "PaidStipend"]
  },
  {
    id: "act_isro_start_2026",
    title: "ISRO START — Space Science & Planetary Exploration Training",
    category: "Workshops",
    organization: "Indian Space Research Organisation (ISRO) & IIRS",
    description: "Introductory online training program covering space science, atmospheric research, planetary exploration, astronomy, and satellite data payload analysis.",
    announcementDate: "2026-09-01",
    registrationStart: "2026-09-15",
    registrationDeadline: "2026-11-28",
    eventStart: "2026-12-08",
    eventEnd: "2026-12-22",
    location: "Online / ISRO E-Class Platform",
    mode: "Online",
    eligibility: "Post-graduate and final-year undergraduate students of physical sciences, technology, and engineering.",
    requiredSkills: ["Basic Physics", "Signals & Coordinate Systems", "Python Data Science basics"],
    requiredDocuments: ["Institutional ID Card", "Nodal Center Nomination Form"],
    stipend: null,
    prizeDetails: "Official ISRO Certificate of Merit upon 70% attendance and passing grading exam",
    officialUrl: "https://jigyasa.iirs.gov.in",
    sourceUrl: "https://jigyasa.iirs.gov.in",
    sourceId: "src_isro_jigyasa",
    verificationStatus: "registration_open",
    isSample: false,
    lastVerified: new Date(Date.now() - 95 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["ISRO", "SpaceScience", "Workshop", "Online", "FreeTraining"]
  },
  {
    id: "act_drdo_trainee_2026",
    title: "DRDO Student Research Trainee & Fellowship Scheme",
    category: "Internships",
    organization: "Defence Research and Development Organisation (DRDO)",
    description: "Opportunity for students to undertake degree project work and technical training inside DRDO laboratories in computer architecture, cybersecurity, and materials science.",
    announcementDate: "2026-08-01",
    registrationStart: "2026-08-15",
    registrationDeadline: "2026-11-30",
    eventStart: "2027-01-05",
    eventEnd: "2027-06-30",
    location: "DRDO Labs (Pune, Bangalore, Hyderabad, Delhi)",
    mode: "Offline",
    eligibility: "Pre-final and final year B.Tech/M.Tech students with consistent 1st class record throughout academics.",
    requiredSkills: ["C/C++", "Cybersecurity", "Signal Processing", "Mathematical Modelling"],
    requiredDocuments: ["Recommendation Letter from Head of Department", "Marks Cards", "Police Verification Affidavit"],
    stipend: "Monthly stipend per Ministry of Defence norms + Research Laboratory Access",
    prizeDetails: null,
    officialUrl: "https://rac.gov.in",
    sourceUrl: "https://rac.gov.in",
    sourceId: "src_drdo_rac",
    verificationStatus: "verified_active",
    isSample: false,
    lastVerified: new Date(Date.now() - 115 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["DRDO", "Research", "DefenceTech", "Fellowship", "InPerson"]
  },
  {
    id: "act_icpc_asia_2026",
    title: "ACM-ICPC Asia Regional Preliminary Coding Contest",
    category: "Coding Competitions",
    organization: "International Collegiate Programming Contest Foundation",
    description: "The premier global collegiate algorithmic programming championship. Teams of 3 university students solve complex algorithmic challenges under strict time and memory constraints.",
    announcementDate: "2026-07-15",
    registrationStart: "2026-08-01",
    registrationDeadline: "2026-11-25",
    eventStart: "2026-12-06",
    eventEnd: "2026-12-07",
    location: "Online Preliminary Round -> Onsite Regional Finals (Amritapuri / Kanpur)",
    mode: "Hybrid",
    eligibility: "College teams of 3 students enrolled in an eligible degree course born in 2002 or later.",
    requiredSkills: ["Data Structures & Algorithms", "C++ / Java / Python / Kotlin", "Dynamic Programming", "Graph Theory"],
    requiredDocuments: ["Faculty Coach Approval", "College Identity Card"],
    stipend: null,
    prizeDetails: "Medals, World Finals Qualifier Slots, and Global High-Frequency Trading Sponsor Interviews",
    officialUrl: "https://icpc.global",
    sourceUrl: "https://icpc.global",
    sourceId: "src_icpc_global",
    verificationStatus: "deadline_approaching",
    isSample: false,
    lastVerified: new Date(Date.now() - 70 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["ICPC", "CompetitiveProgramming", "Algorithms", "GlobalContest", "TeamChallenge"]
  },
  {
    id: "act_ieee_sces_2027",
    title: "IEEE International Student Conference on Engineering & Systems (SCES)",
    category: "Conferences",
    organization: "IEEE India Council & Participating Student Branches",
    description: "Annual peer-reviewed conference providing undergraduate and postgraduate engineering researchers a platform to present technical manuscripts and discuss innovations in smart grid, AI, and robotics.",
    announcementDate: "2026-09-01",
    registrationStart: "2026-09-15",
    registrationDeadline: "2027-01-15",
    eventStart: "2027-03-05",
    eventEnd: "2027-03-07",
    location: "Hybrid (Virtual Presentation & Onsite Nodal Campus)",
    mode: "Hybrid",
    eligibility: "Undergraduate, postgraduate students, and research scholars with original research papers not published elsewhere.",
    requiredSkills: ["LaTeX / IEEE Paper Formatting", "Technical Research", "Data Visualization", "Academic Presentation"],
    requiredDocuments: ["IEEE Manuscript PDF", "Similarity / Plagiarism Check Report (< 15%)"],
    stipend: null,
    prizeDetails: "IEEE Xplore Digital Library publication for accepted papers + Best Student Paper Awards",
    officialUrl: "https://www.ieee.org",
    sourceUrl: "https://www.ieee.org",
    sourceId: "src_ieee_india",
    verificationStatus: "verified_active",
    isSample: false,
    lastVerified: new Date(Date.now() - 130 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["IEEE", "Conference", "ResearchPaper", "IEEE_Xplore", "Engineering"]
  },
  {
    id: "act_mlh_global_2026",
    title: "MLH Global Hack Week — Systems & Open Source Edition",
    category: "Hackathons",
    organization: "Major League Hacking (MLH)",
    description: "Week-long beginner-friendly technical festival featuring daily coding challenges, mentor workshops, live peer streams, and open-source project building.",
    announcementDate: "2026-10-01",
    registrationStart: "2026-10-05",
    registrationDeadline: "2026-12-01",
    eventStart: "2026-12-04",
    eventEnd: "2026-12-11",
    location: "Global / Discord & Twitch",
    mode: "Online",
    eligibility: "Open to all students worldwide. Solo hackers and teams of up to 4 welcomed.",
    requiredSkills: ["Git", "Web Development", "Python / JavaScript", "Beginner Hackers Welcome"],
    requiredDocuments: ["MLH Participant Registration"],
    stipend: null,
    prizeDetails: "Digital Swag, Cloud Credits, Community Badges, and Hardware Kits for track winners",
    officialUrl: "https://mlh.io",
    sourceUrl: "https://mlh.io",
    sourceId: "src_mlh_hackathons",
    verificationStatus: "registration_open",
    isSample: false,
    lastVerified: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["MLH", "GlobalHackWeek", "BeginnerFriendly", "Virtual", "Community"]
  },
  {
    id: "act_aws_workshop_2026",
    title: "AWS Cloud Architecture & Serverless Deep-Dive Workshop",
    category: "Workshops",
    organization: "AWS User Group India & AWS Academy",
    description: "Hands-on builder workshop on deploying microservices using AWS Lambda, DynamoDB, Amazon API Gateway, and CloudFront. Includes complimentary AWS promotional credits.",
    announcementDate: "2026-10-15",
    registrationStart: "2026-10-20",
    registrationDeadline: "2026-11-22",
    eventStart: "2026-11-29",
    eventEnd: "2026-11-29",
    location: "Online Virtual Lab",
    mode: "Online",
    eligibility: "Open to college students interested in cloud computing and backend architecture.",
    requiredSkills: ["Basic JavaScript / Python", "Understanding of HTTP requests"],
    requiredDocuments: ["College Email or Student ID"],
    stipend: null,
    prizeDetails: "Free AWS Certificate of Completion + $25 AWS Promotional Credits",
    officialUrl: "https://aws.amazon.com/developer/community/usergroups",
    sourceUrl: "https://aws.amazon.com/developer/community/usergroups",
    sourceId: "src_aws_india",
    verificationStatus: "deadline_approaching",
    isSample: false,
    lastVerified: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["AWS", "Cloud", "Serverless", "FreeCredits", "Workshop"]
  },
  {
    id: "act_sample_tcs_codevita",
    title: "TCS CodeVita Global Coding Championship (Sample Reference)",
    category: "Coding Competitions",
    organization: "Tata Consultancy Services (Sample Demonstration Entry)",
    description: "Sample entry illustrating an international competitive programming championship featuring multi-round algorithmic challenges and direct interview opportunities.",
    announcementDate: "2026-07-01",
    registrationStart: "2026-08-01",
    registrationDeadline: "2026-12-10",
    eventStart: "2026-12-20",
    eventEnd: "2026-12-21",
    location: "Online / Pan-India",
    mode: "Online",
    eligibility: "Engineering students graduating in 2027 or 2028 across recognized institutions.",
    requiredSkills: ["C++", "Java", "Python", "Problem Solving"],
    requiredDocuments: ["College Enrollment Proof"],
    stipend: null,
    prizeDetails: "USD $20,000 Total Prize Pool + Fast-Track Technical Interviews",
    officialUrl: "https://campuscommune.tcs.com",
    sourceUrl: "https://campuscommune.tcs.com",
    sourceId: "src_sample_demo",
    verificationStatus: "sample",
    isSample: true,
    lastVerified: new Date(Date.now() - 180 * 60 * 1000).toISOString(),
    missingFields: [],
    uncertainFields: [],
    tags: ["SampleListing", "CodingCompetition", "TCS", "Algorithms"]
  }
];

class ActivitiesStore {
  constructor() {
    this.opportunities = new Map();
    this.sources = new Map();
    this.refreshHistory = [];
    this.lastRefreshedAt = new Date().toISOString();
    this.isRefreshing = false;

    // Load initial seeds
    for (const src of ACTIVITY_SOURCES) {
      this.sources.set(src.id, Object.assign({}, src));
    }
    for (const opp of SEED_OPPORTUNITIES) {
      this.opportunities.set(opp.id, Object.assign({}, opp));
    }
  }

  computeFingerprint(record) {
    const raw = `${record.title || ''}|${record.organization || ''}|${record.registrationDeadline || ''}|${record.officialUrl || ''}`;
    return crypto.createHash("sha256").update(raw.toLowerCase().trim()).digest("hex").slice(0, 16);
  }

  getAll({ category = "all", search = "", mode = "all", deadline = "all", verification = "all", isSample = "all", page = 1, limit = 20, sort = "announcement" } = {}) {
    let list = Array.from(this.opportunities.values());

    // Category filter
    if (category && category !== "all" && category !== "All Activities") {
      const targetCat = category.toLowerCase();
      list = list.filter((opp) => {
        const c = (opp.category || "").toLowerCase();
        return c === targetCat || (targetCat === "scholarships" && c.includes("scholarship")) || (targetCat === "hackathons" && c.includes("hackathon"));
      });
    }

    // Search filter
    if (search && typeof search === "string" && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter((opp) => {
        const text = [
          opp.title,
          opp.organization,
          opp.description,
          opp.category,
          opp.location,
          (opp.requiredSkills || []).join(" "),
          (opp.tags || []).join(" ")
        ].join(" ").toLowerCase();
        return text.includes(q);
      });
    }

    // Mode filter
    if (mode && mode !== "all") {
      const m = mode.toLowerCase();
      list = list.filter((opp) => (opp.mode || "").toLowerCase() === m);
    }

    // Deadline filter
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    if (deadline === "active") {
      list = list.filter((opp) => !opp.registrationDeadline || opp.registrationDeadline >= todayStr);
    } else if (deadline === "approaching") {
      const in7Days = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
      list = list.filter((opp) => opp.registrationDeadline && opp.registrationDeadline >= todayStr && opp.registrationDeadline <= in7Days);
    } else if (deadline === "expired") {
      list = list.filter((opp) => opp.registrationDeadline && opp.registrationDeadline < todayStr);
    }

    // Verification status filter
    if (verification && verification !== "all") {
      if (verification === "verified_only") {
        list = list.filter((opp) => !opp.isSample && opp.verificationStatus !== "sample");
      } else {
        list = list.filter((opp) => opp.verificationStatus === verification);
      }
    }

    // Sample separation
    if (isSample === "real") {
      list = list.filter((opp) => !opp.isSample);
    } else if (isSample === "sample") {
      list = list.filter((opp) => opp.isSample);
    }

    // Dynamic verification status refresh based on dates
    list = list.map((opp) => {
      const refreshed = Object.assign({}, opp);
      if (refreshed.registrationDeadline && refreshed.registrationDeadline < todayStr && !refreshed.isSample) {
        refreshed.verificationStatus = "expired";
      } else if (refreshed.registrationDeadline && refreshed.registrationDeadline <= new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10) && !refreshed.isSample) {
        if (refreshed.registrationDeadline >= todayStr) {
          refreshed.verificationStatus = "deadline_approaching";
        }
      }
      return refreshed;
    });

    // Sorting
    list.sort((a, b) => {
      if (sort === "deadline") {
        if (!a.registrationDeadline) return 1;
        if (!b.registrationDeadline) return -1;
        return a.registrationDeadline.localeCompare(b.registrationDeadline);
      }
      if (sort === "eventDate") {
        if (!a.eventStart) return 1;
        if (!b.eventStart) return -1;
        return a.eventStart.localeCompare(b.eventStart);
      }
      if (sort === "recentlyVerified") {
        return (b.lastVerified || "").localeCompare(a.lastVerified || "");
      }
      // default: announcementDate (newest first)
      const aDate = a.announcementDate || a.registrationStart || "1970-01-01";
      const bDate = b.announcementDate || b.registrationStart || "1970-01-01";
      return bDate.localeCompare(aDate);
    });

    const total = list.length;
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
    const startIndex = (pageNum - 1) * limitNum;
    const items = list.slice(startIndex, startIndex + limitNum);

    return {
      items,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum) || 1
      }
    };
  }

  getById(id) {
    if (!id) return null;
    return this.opportunities.get(id) || null;
  }

  getLatest(limit = 6) {
    const all = Array.from(this.opportunities.values());
    all.sort((a, b) => {
      const aDate = a.announcementDate || a.registrationStart || "1970-01-01";
      const bDate = b.announcementDate || b.registrationStart || "1970-01-01";
      return bDate.localeCompare(aDate);
    });
    return all.slice(0, Math.max(1, parseInt(limit, 10) || 6));
  }

  getCategories() {
    const all = Array.from(this.opportunities.values());
    const counts = {};
    for (const cat of CATEGORIES) {
      counts[cat] = 0;
    }
    counts["All Activities"] = all.length;

    for (const opp of all) {
      const cat = opp.category;
      if (counts[cat] !== undefined) {
        counts[cat] += 1;
      } else {
        counts["Other Opportunities"] = (counts["Other Opportunities"] || 0) + 1;
      }
    }

    return CATEGORIES.map((name) => ({
      name,
      count: counts[name] || 0
    }));
  }

  getDeadlines() {
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const tomorrowDate = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const tomorrowStr = tomorrowDate.toISOString().slice(0, 10);
    const in3DaysStr = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const in7DaysStr = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

    const todayList = [];
    const tomorrowList = [];
    const within3DaysList = [];
    const within7DaysList = [];
    const expiredList = [];
    const upcomingList = [];

    for (const opp of this.opportunities.values()) {
      if (!opp.registrationDeadline) continue;
      const d = opp.registrationDeadline;
      if (d === todayStr) {
        todayList.push(opp);
      } else if (d === tomorrowStr) {
        tomorrowList.push(opp);
      } else if (d > tomorrowStr && d <= in3DaysStr) {
        within3DaysList.push(opp);
      } else if (d > in3DaysStr && d <= in7DaysStr) {
        within7DaysList.push(opp);
      } else if (d < todayStr) {
        expiredList.push(opp);
      } else {
        upcomingList.push(opp);
      }
    }

    const sortByDeadline = (a, b) => a.registrationDeadline.localeCompare(b.registrationDeadline);
    todayList.sort(sortByDeadline);
    tomorrowList.sort(sortByDeadline);
    within3DaysList.sort(sortByDeadline);
    within7DaysList.sort(sortByDeadline);
    expiredList.sort(sortByDeadline);
    upcomingList.sort(sortByDeadline);

    return {
      today: todayList,
      tomorrow: tomorrowList,
      within3Days: within3DaysList,
      within7Days: within7DaysList,
      expired: expiredList,
      upcoming: upcomingList
    };
  }

  getCalendar({ year, month } = {}) {
    const now = new Date();
    const targetYear = parseInt(year, 10) || now.getFullYear();
    const targetMonth = parseInt(month, 10) || (now.getMonth() + 1); // 1-12
    const prefix = `${targetYear}-${String(targetMonth).padStart(2, "0")}`;

    const events = [];
    for (const opp of this.opportunities.values()) {
      // 1. Registration Deadline Event
      if (opp.registrationDeadline && opp.registrationDeadline.startsWith(prefix)) {
        events.push({
          id: `${opp.id}_deadline`,
          opportunityId: opp.id,
          title: `Deadline: ${opp.title}`,
          date: opp.registrationDeadline,
          type: "deadline",
          category: opp.category,
          mode: opp.mode,
          organization: opp.organization,
          officialUrl: opp.officialUrl,
          isSample: opp.isSample
        });
      }
      // 2. Event Start
      if (opp.eventStart && opp.eventStart.startsWith(prefix)) {
        events.push({
          id: `${opp.id}_start`,
          opportunityId: opp.id,
          title: `Starts: ${opp.title}`,
          date: opp.eventStart,
          type: "event_start",
          category: opp.category,
          mode: opp.mode,
          organization: opp.organization,
          officialUrl: opp.officialUrl,
          isSample: opp.isSample
        });
      }
      // 3. Event End
      if (opp.eventEnd && opp.eventEnd.startsWith(prefix)) {
        events.push({
          id: `${opp.id}_end`,
          opportunityId: opp.id,
          title: `Ends: ${opp.title}`,
          date: opp.eventEnd,
          type: "event_end",
          category: opp.category,
          mode: opp.mode,
          organization: opp.organization,
          officialUrl: opp.officialUrl,
          isSample: opp.isSample
        });
      }
    }

    events.sort((a, b) => a.date.localeCompare(b.date));

    return {
      year: targetYear,
      month: targetMonth,
      totalEvents: events.length,
      events
    };
  }

  getRefreshStatus() {
    const all = Array.from(this.opportunities.values());
    const realOpps = all.filter((o) => !o.isSample);
    const sampleOpps = all.filter((o) => o.isSample);
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const in7DaysStr = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

    const verifiedActive = realOpps.filter((o) => o.verificationStatus === "verified_active" || o.verificationStatus === "registration_open");
    const upcoming = realOpps.filter((o) => o.verificationStatus === "upcoming");
    const deadlineApproaching = realOpps.filter((o) => o.registrationDeadline && o.registrationDeadline >= todayStr && o.registrationDeadline <= in7DaysStr);
    const expired = realOpps.filter((o) => o.registrationDeadline && o.registrationDeadline < todayStr);
    const pendingReview = realOpps.filter((o) => o.verificationStatus === "verification_pending");

    const sourceList = Array.from(this.sources.values());
    const enabledSources = sourceList.filter((s) => s.isEnabled);
    const activeHealthySources = enabledSources.filter((s) => !s.lastFailedRefresh || (s.lastSuccessfulRefresh && s.lastSuccessfulRefresh > s.lastFailedRefresh));
    const failedSources = enabledSources.filter((s) => s.lastFailedRefresh && (!s.lastSuccessfulRefresh || s.lastFailedRefresh > s.lastSuccessfulRefresh));

    return {
      lastRefreshedAt: this.lastRefreshedAt,
      refreshIntervalMinutes: 360,
      isRefreshing: this.isRefreshing,
      metrics: {
        totalOpportunities: all.length,
        totalRealOpportunities: realOpps.length,
        verifiedActiveCount: verifiedActive.length,
        registrationOpenCount: realOpps.filter((o) => o.verificationStatus === "registration_open").length,
        upcomingCount: upcoming.length,
        deadlineApproachingCount: deadlineApproaching.length,
        expiredCount: expired.length,
        pendingReviewCount: pendingReview.length,
        sampleCount: sampleOpps.length,
        sourcesConfigured: sourceList.length,
        sourcesActive: activeHealthySources.length,
        sourcesFailed: failedSources.length
      },
      sources: sourceList
    };
  }

  upsertOpportunity(oppData) {
    if (!oppData || !oppData.title) return null;
    const fingerprint = this.computeFingerprint(oppData);

    // Duplicate check by URL or fingerprint
    for (const existing of this.opportunities.values()) {
      if (
        (oppData.officialUrl && existing.officialUrl && oppData.officialUrl.toLowerCase() === existing.officialUrl.toLowerCase()) ||
        (oppData.contentFingerprint && existing.contentFingerprint && oppData.contentFingerprint === existing.contentFingerprint) ||
        (existing.contentFingerprint === fingerprint)
      ) {
        // Merge without overwriting manually verified fields
        const updated = Object.assign({}, existing, oppData, {
          id: existing.id,
          contentFingerprint: fingerprint,
          lastVerified: new Date().toISOString()
        });
        this.opportunities.set(existing.id, updated);
        return { action: "updated", record: updated };
      }
    }

    const newId = oppData.id || `act_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const newRecord = Object.assign({}, oppData, {
      id: newId,
      contentFingerprint: fingerprint,
      lastVerified: oppData.lastVerified || new Date().toISOString()
    });
    this.opportunities.set(newId, newRecord);
    return { action: "inserted", record: newRecord };
  }

  recordRefreshResult({ discovered = 0, updated = 0, rejected = 0, failedSources = 0, summary = {} } = {}) {
    this.lastRefreshedAt = new Date().toISOString();
    this.isRefreshing = false;
    const logEntry = {
      id: `log_${Date.now()}`,
      timestamp: this.lastRefreshedAt,
      discoveredCount: discovered,
      updatedCount: updated,
      rejectedCount: rejected,
      failedSourcesCount: failedSources,
      status: failedSources > 0 ? "completed_with_warnings" : "completed",
      summary
    };
    this.refreshHistory.unshift(logEntry);
    if (this.refreshHistory.length > 50) {
      this.refreshHistory.pop();
    }
    return logEntry;
  }

  getSources() {
    return Array.from(this.sources.values());
  }

  getRefreshHistory() {
    return this.refreshHistory;
  }
}

const storeInstance = new ActivitiesStore();

module.exports = storeInstance;
module.exports.CATEGORIES = CATEGORIES;
