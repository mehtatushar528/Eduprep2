const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

const files = [
  'home_dashboard/code.html',
  'previous_year_papers/code.html',
  'academic_setup/code.html',
  'activities/code.html',
  'user_profile_progress/code.html',
  'mcq_practice_exam/code.html',
  'revision_flashcards/code.html',
  'resources_dashboard/code.html',
  'questions_practice/code.html',
  'subject_details/code.html',
  'subject_details_os/code.html',
  'student_opportunities/code.html',
  'study_ai_assistant/code.html',
  'admin_panel/code.html',
  'affiliated_college_selection/code.html',
  'ai_tutor_personality_setup/code.html',
  'login_registration/code.html',
  'academic_setup_updated_flow/code.html',
  '404.html'
];

files.forEach(f => {
  const full = path.join(base, f);
  if (!fs.existsSync(full)) {
    console.log('MISSING:', f);
    return;
  }
  const content = fs.readFileSync(full, 'utf8');
  const headerMatch = content.match(/<header[\s\S]*?<\/header>/);
  if (headerMatch) {
    console.log(`=== ${f} HEADER (len: ${headerMatch[0].length}) ===`);
    console.log(headerMatch[0].split('\n').slice(0, 15).join('\n'));
    console.log('...');
  } else {
    console.log(`=== ${f} NO <header> TAG FOUND ===`);
  }
});
