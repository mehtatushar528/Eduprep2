const fs = require("fs");
const p = "./EduPrep/EduPrep/home_dashboard/code.html";
const content = fs.readFileSync(p, "utf8");
const lines = content.split("\n");
lines.forEach((l, i) => {
  if (l.includes("Practice Exam →")) {
    console.log(`Found around line ${i + 1}`);
    for (let c = Math.max(0, i - 15); c <= Math.min(lines.length - 1, i + 10); c++) {
      console.log(`${c + 1}: ${lines[c]}`);
    }
  }
});
