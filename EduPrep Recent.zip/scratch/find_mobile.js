const fs = require('fs');
const txt = fs.readFileSync('C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\previous_year_papers\\code.html', 'utf8');
const lines = txt.split('\n');
lines.forEach((l, i) => {
  if (l.includes('bottom') || l.includes('md:hidden')) {
    console.log((i+1) + ': ' + l.trim());
  }
});
