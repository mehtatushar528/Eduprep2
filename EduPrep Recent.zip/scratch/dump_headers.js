const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

const pages = [
  'home_dashboard/code.html',
  'previous_year_papers/code.html',
  'academic_setup/code.html',
  'activities/code.html',
  'user_profile_progress/code.html',
  'mcq_practice_exam/code.html',
  'revision_flashcards/code.html',
  'resources_dashboard/code.html'
];

pages.forEach(p => {
  const full = path.join(base, p);
  const txt = fs.readFileSync(full, 'utf8');
  const m = txt.match(/<header[\s\S]*?<\/header>/);
  if (m) {
    console.log(`\n=================== ${p} ===================`);
    console.log(m[0]);
  }
});
