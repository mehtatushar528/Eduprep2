/**
 * EduPrep Master Expansion Automated Test Suite
 * Validates:
 * 1. 70-Subject Catalog Integrity & 420-Chapter Completeness across 4 Streams
 * 2. 22 Required Study Sections in every chapter's detailed notes
 * 3. Pure-JS Standards-Compliant Chapter PDF Generator (%PDF-1.4)
 * 4. Expanded MCQ Bank (>= 30 per chapter, 30% Easy / 40% Medium / 30% Hard)
 * 5. Expanded 3D Flashcard Library (>= 20 per chapter with 3D flip card schema)
 * 6. Genuine PYQ Archive with Authentic University Portals & Weightage
 * 7. Real Student Opportunities across 10 Categories with Active/Expired Filtering
 * 8. Global Public Resource Search across All Educational Dimensions
 * 9. API Security & Server Health Status Module (/api/api-status)
 */

const { describe, it } = require("node:test");
const assert = require("node:assert/strict");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const eduPrepSharedDir = path.join(rootDir, "EduPrep", "shared");

// Load modules
const EduPrep = require(path.join(eduPrepSharedDir, "eduprep_data.js"));
const ChaptersEngine = require(path.join(eduPrepSharedDir, "eduprep_chapters_data.js"));
const PyqEngine = require(path.join(eduPrepSharedDir, "eduprep_pyq_data.js"));
const EduPrepServices = require(path.join(eduPrepSharedDir, "eduprep_services.js"));
const apiStatusHandler = require(path.join(rootDir, "api", "api-status.js"));

describe("EduPrep Master Expansion & Content Completeness Suite", () => {

  // =========================================================================
  // 1. 70-SUBJECT CATALOG & 420-CHAPTER COMPLETENESS
  // =========================================================================
  describe("70-Subject Catalog & 420-Chapter Completeness", () => {
    it("preserves exact stream subject counts totaling 70 subjects", () => {
      assert.equal(EduPrep.STREAM_SUBJECTS.engineering.length, 25, "Engineering must have 25 subjects");
      assert.equal(EduPrep.STREAM_SUBJECTS.medical.length, 15, "Medical must have 15 subjects");
      assert.equal(EduPrep.STREAM_SUBJECTS.commerce.length, 15, "Commerce must have 15 subjects");
      assert.equal(EduPrep.STREAM_SUBJECTS.arts.length, 15, "Arts must have 15 subjects");
      
      const total = EduPrep.STREAM_SUBJECTS.engineering.length +
                    EduPrep.STREAM_SUBJECTS.medical.length +
                    EduPrep.STREAM_SUBJECTS.commerce.length +
                    EduPrep.STREAM_SUBJECTS.arts.length;
      assert.equal(total, 70, "Total subjects across all streams must be 70");
    });

    it("verifies every subject has complete chapters (420 chapters total across 70 subjects)", () => {
      const streams = ["engineering", "medical", "commerce", "arts"];
      let chapterTotal = 0;

      streams.forEach((st) => {
        const subjects = EduPrep.STREAM_SUBJECTS[st];
        subjects.forEach((subj) => {
          const chs = ChaptersEngine.getChapters(subj);
          assert.ok(chs.length >= 5, `${subj} in ${st} must have chapters (got ${chs.length})`);
          chapterTotal += chs.length;
        });
      });

      assert.equal(chapterTotal, 420, "Total chapters across 70 subjects must be 420");
    });

    it("reports 100% chapter completeness meeting MCQ and flashcard targets for sample chapters across streams", () => {
      const testChapters = [
        "ch_dbms_s4_1",          // Engineering
        "ch_med_anatomy_s1_1",   // Medical
        "ch_com_fin_acc_s1_1",   // Commerce
        "ch_arts_history_s1_1"   // Arts
      ];

      testChapters.forEach((chId) => {
        const completeness = ChaptersEngine.getChapterCompleteness(chId);
        assert.ok(completeness, `Completeness record must exist for ${chId}`);
        assert.equal(completeness.status, "complete", `Chapter ${chId} must be complete`);
        assert.equal(completeness.mcqTargetMet, true, `Chapter ${chId} must meet MCQ target`);
        assert.ok(completeness.mcqsCount >= 30, `Chapter ${chId} must have at least 30 MCQs`);
        assert.ok(completeness.flashcardsCount >= 20, `Chapter ${chId} must have at least 20 flashcards`);
      });
    });
  });

  // =========================================================================
  // 2. 22 REQUIRED STUDY SECTIONS IN CHAPTER NOTES
  // =========================================================================
  describe("22 Required Study Sections in Chapter Notes", () => {
    it("supplies all 22 required academic sections in detailed chapter notes", () => {
      const sampleSubjects = [
        "Operating Systems",
        "Anatomy",
        "Financial Accounting",
        "Political Science"
      ];

      sampleSubjects.forEach((subj) => {
        const chapters = ChaptersEngine.getChapters(subj);
        assert.ok(chapters.length > 0);
        const ch = chapters[0];
        const notes = ch.notes;
        assert.ok(notes, `Chapter ${ch.title} must have notes`);

        // 1. Overview & Objectives
        assert.ok(notes.overview && notes.overview.length > 20, "Must have comprehensive overview");
        assert.ok(Array.isArray(notes.learningObjectives) && notes.learningObjectives.length >= 4, "Must have >= 4 learning objectives");

        // 2. Definitions & Terminology
        assert.ok(Array.isArray(notes.keyDefinitions) && notes.keyDefinitions.length >= 6, "Must have >= 6 key definitions");
        notes.keyDefinitions.forEach((def) => {
          assert.ok(def.term && def.term.length > 0, "Definition must have term");
          assert.ok(def.definition && def.definition.length > 10, "Definition must have explanation");
          assert.ok(def.academicSignificance, "Must have academic significance");
          assert.ok(def.examRelevance, "Must have exam relevance");
        });

        // 3. Conceptual Explanations
        assert.ok(Array.isArray(notes.conceptualExplanations) && notes.conceptualExplanations.length >= 4, "Must have >= 4 conceptual topics");
        notes.conceptualExplanations.forEach((exp) => {
          assert.ok(exp.heading, "Must have heading");
          assert.ok(exp.explanation && exp.explanation.length > 30, "Must have deep-dive explanation");
          assert.ok(exp.keyTakeaway, "Must have key takeaway");
        });

        // 4. Formulas / Rules / Principles
        assert.ok(Array.isArray(notes.formulasOrRules) && notes.formulasOrRules.length >= 3, "Must have >= 3 formulas/rules");
        notes.formulasOrRules.forEach((fr) => {
          assert.ok(fr.rule, "Must have rule name");
          assert.ok(fr.statement, "Must have statement");
          assert.ok(fr.symbolsOrComponents, "Must define symbols/components");
          assert.ok(fr.unitsOrConditions, "Must define units/conditions");
          assert.ok(fr.practicalSignificance, "Must define practical significance");
        });

        // 5. Step-by-Step Solved Problems
        assert.ok(Array.isArray(notes.examplesOrProblems) && notes.examplesOrProblems.length >= 3, "Must have >= 3 solved problems");
        notes.examplesOrProblems.forEach((prob) => {
          assert.ok(prob.title, "Problem must have title");
          assert.ok(prob.problemStatement, "Must have problem statement");
          assert.ok(prob.given, "Must state Given parameters");
          assert.ok(prob.required, "Must state Required outcome");
          assert.ok(prob.conceptOrFormula, "Must state Governing concept/formula");
          assert.ok(Array.isArray(prob.stepByStepSolution) && prob.stepByStepSolution.length >= 2, "Must have step-by-step solution");
          assert.ok(prob.finalAnswer, "Must have final answer");
          assert.ok(prob.explanation, "Must have conceptual explanation");
        });

        // 6. SVG Diagram
        assert.ok(notes.svgDiagram && notes.svgDiagram.includes("<svg") && notes.svgDiagram.includes("</svg>"), "Must include responsive SVG diagram");

        // 7. Comparative Concept Matrix
        assert.ok(notes.comparativeMatrix, "Must have comparative matrix");
        assert.ok(Array.isArray(notes.comparativeMatrix.headers) && notes.comparativeMatrix.headers.length >= 3, "Matrix must have >= 3 columns");
        assert.ok(Array.isArray(notes.comparativeMatrix.rows) && notes.comparativeMatrix.rows.length >= 3, "Matrix must have >= 3 comparison rows");

        // 8. Practical Applications & Common Mistakes
        assert.ok(Array.isArray(notes.practicalApplications) && notes.practicalApplications.length >= 3, "Must have >= 3 practical applications");
        assert.ok(Array.isArray(notes.commonMistakesAndPitfalls) && notes.commonMistakesAndPitfalls.length >= 3, "Must have >= 3 common mistakes");

        // 9. Exam Tips & Rubrics
        assert.ok(notes.examTipsAndTricks, "Must have exam tips");
        assert.ok(notes.examTipsAndTricks.twoMarkStrategy, "Must have 2-mark strategy");
        assert.ok(notes.examTipsAndTricks.fiveMarkStrategy, "Must have 5-mark strategy");
        assert.ok(notes.examTipsAndTricks.tenMarkStrategy, "Must have 10-mark strategy");
        assert.ok(Array.isArray(notes.examTipsAndTricks.highYieldKeywords), "Must have high-yield keywords");

        // 10. Revision Points & Summary
        assert.ok(Array.isArray(notes.revisionQuickReferencePoints) && notes.revisionQuickReferencePoints.length >= 8, "Must have >= 8 revision points");
        assert.ok(notes.chapterSummary && notes.chapterSummary.length > 20, "Must have chapter summary");
      });
    });
  });

  // =========================================================================
  // 3. PURE-JS CHAPTER PDF GENERATOR
  // =========================================================================
  describe("Pure-JS Chapter PDF Document Generator", () => {
    it("generates standards-compliant PDF 1.4 buffer for chapter notes without external binaries", () => {
      const chapter = ChaptersEngine.getChapterById("ch_dbms_s4_1");
      const meta = ChaptersEngine.getSubjectMeta("Database Management Systems");
      assert.ok(chapter, "Chapter must exist");

      const pdf = ChaptersEngine.generateChapterPdfBuffer(chapter, meta);
      assert.ok(typeof pdf === "string", "PDF must be generated as string buffer");
      assert.ok(pdf.startsWith("%PDF-1.4"), "PDF must have %PDF-1.4 magic header");
      assert.ok(pdf.includes("/Type /Catalog"), "PDF must contain Catalog object");
      assert.ok(pdf.includes("/Type /Pages"), "PDF must contain Pages object");
      assert.ok(pdf.includes("/Type /Page"), "PDF must contain Page object");
      assert.ok(pdf.includes("/Type /Font"), "PDF must contain Font definitions");
      assert.ok(pdf.includes("xref"), "PDF must contain xref table");
      assert.ok(pdf.includes("trailer"), "PDF must contain trailer");
      assert.ok(pdf.includes("startxref"), "PDF must contain startxref");
      assert.ok(pdf.endsWith("%%EOF\n"), "PDF must terminate with %%EOF tag");

      // Verify content presence in PDF
      assert.ok(pdf.includes("EDUPREP ACADEMIC STUDY COMPANION"), "Must contain header banner");
      assert.ok(pdf.includes("Database Management Systems"), "Must contain subject name");
      assert.ok(pdf.includes("LEARNING OBJECTIVES"), "Must contain learning objectives header");
      assert.ok(pdf.includes("KEY DEFINITIONS"), "Must contain definitions header");
      assert.ok(pdf.includes("SOLVED EXAM PROBLEMS"), "Must contain solved problems header");
    });
  });

  // =========================================================================
  // 4. MCQ QUESTION BANK WITH TARGET DIFFICULTY DISTRIBUTION
  // =========================================================================
  describe("MCQ Question Bank with Target Difficulty Distribution", () => {
    it("supplies at least 30 MCQs per chapter with valid schema", () => {
      const testCases = [
        { subject: "Operating Systems", chapterId: "ch_os_s4_1" },
        { subject: "Anatomy", chapterId: "ch_med_anatomy_s1_1" },
        { subject: "Financial Accounting", chapterId: "ch_com_fin_acc_s1_1" },
        { subject: "History", chapterId: "ch_arts_history_s1_1" }
      ];

      testCases.forEach(({ subject, chapterId }) => {
        const mcqs = ChaptersEngine.getSubjectMcqs(subject, chapterId);
        assert.ok(mcqs.length >= 30, `Subject ${subject} (${chapterId}) must have >= 30 MCQs, got ${mcqs.length}`);

        // Validate difficulty distribution (~30% Easy, ~40% Medium, ~30% Difficult)
        const easy = mcqs.filter(m => m.difficulty === "easy").length;
        const med = mcqs.filter(m => m.difficulty === "medium").length;
        const diff = mcqs.filter(m => m.difficulty === "difficult").length;

        const easyPct = Math.round((easy / mcqs.length) * 100);
        const medPct = Math.round((med / mcqs.length) * 100);
        const diffPct = Math.round((diff / mcqs.length) * 100);

        assert.ok(easyPct >= 20 && easyPct <= 35, `Easy percentage should be ~30% (got ${easyPct}%)`);
        assert.ok(medPct >= 35 && medPct <= 50, `Medium percentage should be ~40% (got ${medPct}%)`);
        assert.ok(diffPct >= 20 && diffPct <= 35, `Difficult percentage should be ~30% (got ${diffPct}%)`);

        // Validate schema
        mcqs.forEach((m) => {
          assert.ok(m.id, "MCQ must have ID");
          assert.ok(m.q && m.q.length >= 10, "MCQ must have valid question statement");
          assert.equal(m.options.length, 4, "MCQ must have exactly 4 options");
          assert.ok([0, 1, 2, 3].includes(m.answer), "MCQ answer index must be 0-3");
          assert.ok([0, 1, 2, 3].includes(m.ans), "MCQ ans index must be 0-3");
          assert.ok(m.explanation && m.explanation.length >= 10, "MCQ must have explanation");
          assert.ok(["easy", "medium", "difficult"].includes(m.difficulty), "Valid difficulty");
          assert.equal(m.reviewStatus, "reviewed", "MCQ reviewStatus must be reviewed");
        });
      });
    });
  });

  // =========================================================================
  // 5. FLASHCARD LIBRARY WITH 3D FLIP CARD ATTRIBUTES
  // =========================================================================
  describe("Flashcard Library with 3D Flip Card Attributes", () => {
    it("supplies at least 20 flashcards per chapter with comprehensive card types", () => {
      const testCases = [
        { subject: "Data Structures", chapterId: "ch_data_structures_s3_1" },
        { subject: "Physiology", chapterId: "ch_med_physiology_s1_1" },
        { subject: "Business Economics", chapterId: "ch_com_bus_econ_s1_1" },
        { subject: "Sociology", chapterId: "ch_arts_sociology_s1_1" }
      ];

      testCases.forEach(({ subject, chapterId }) => {
        const cards = ChaptersEngine.getSubjectFlashcards(subject, chapterId);
        assert.ok(cards.length >= 20, `Subject ${subject} (${chapterId}) must have >= 20 flashcards, got ${cards.length}`);

        const types = new Set(cards.map(c => c.cardType));
        assert.ok(types.has("definition"), "Deck must contain definition cards");
        assert.ok(types.has("concept"), "Deck must contain concept cards");
        assert.ok(types.has("formula") || types.has("difference") || types.has("problem"), "Deck must contain analytical cards");

        cards.forEach((c) => {
          assert.ok(c.id, "Flashcard must have ID");
          assert.ok(c.q && c.q.length >= 5, "Card must have question/front prompt");
          assert.ok(c.a && c.a.length >= 5, "Card must have answer/back explanation");
          assert.ok(c.chapterId, "Card must reference valid chapterId");
          assert.ok(c.examRelevance, "Card must have exam relevance tag");
        });
      });
    });
  });

  // =========================================================================
  // 6. GENUINE PREVIOUS YEAR PAPERS ARCHIVE & WEIGHTAGE
  // =========================================================================
  describe("Genuine Previous Year Papers Archive & Weightage", () => {
    it("provides 2024, 2023, 2022 examination papers with authentic public portals and no sample disguise", () => {
      const papers = PyqEngine.getPapersForSubject("Operating Systems");
      assert.ok(papers.length >= 3, "Must have papers for 2024, 2023, 2022");

      papers.forEach((p) => {
        assert.ok(!p.isSample, "Official/public archive papers must have isSample: false");
        assert.ok(["verified_official", "verified_public"].includes(p.verificationStatus), "Must have verified status");
        assert.ok(p.sourceUrl && p.sourceUrl.startsWith("http"), "Must link to legitimate examination source portal");
        assert.ok(p.sourceAttribution, "Must state source attribution");
        assert.ok(p.lastCheckedDate, "Must record lastCheckedDate");
        assert.equal(p.duration, "3 Hours");
        assert.equal(p.maxMarks, 80);
      });
    });

    it("calculates accurate weightage metrics reporting verified papers analyzed", () => {
      const papers = PyqEngine.getPapersForSubject("Database Management Systems");
      const weightage = PyqEngine.calculateWeightage(papers);

      assert.ok(weightage.papersCount >= 3, "Must analyze >= 3 papers");
      assert.ok(weightage.verifiedPapersCount >= 3, "Must report verified papers count");
      assert.equal(weightage.samplePapersCount, 0, "No sample papers disguised as official");
      assert.ok(weightage.totalMarks > 0);
      assert.ok(weightage.totalQuestions > 0);
      assert.ok(Array.isArray(weightage.chapterWeightage));
    });
  });

  // =========================================================================
  // 7. REAL OPPORTUNITIES DATABASE ACROSS 10 CATEGORIES
  // =========================================================================
  describe("Real Opportunities Database Across 10 Categories", () => {
    it("covers all 10 required student opportunity categories with legitimate URLs", () => {
      const opps = EduPrep.opportunities;
      assert.ok(Array.isArray(opps));
      assert.ok(opps.length >= 10, "Must have >= 10 genuine opportunities");

      const categories = new Set(opps.map(o => o.category));
      assert.ok(categories.has("Hackathon"), "Must support Hackathons");
      assert.ok(categories.has("Internship"), "Must support Internships");
      assert.ok(categories.has("Government Scholarship"), "Must support Government Scholarships");
      assert.ok(categories.has("Private Scholarship"), "Must support Private Scholarships");
      assert.ok(categories.has("Workshop"), "Must support Workshops");
      assert.ok(categories.has("Event"), "Must support Technical Events");
      assert.ok(categories.has("Competition"), "Must support Competitions");
      assert.ok(categories.has("Conference"), "Must support Conferences");
      assert.ok(categories.has("Webinar"), "Must support Webinars");
      assert.ok(categories.has("Career"), "Must support Career Programs");

      // Verify every opportunity has real URLs and metadata
      opps.forEach((o) => {
        assert.ok(o.id, "Must have ID");
        assert.ok(o.title, "Must have title");
        assert.ok(o.organizer || o.organization, "Must state legitimate organizer");
        assert.ok(o.deadlineDate, "Must have deadlineDate");
        assert.ok(o.applyUrl && (o.applyUrl.startsWith("http://") || o.applyUrl.startsWith("https://")), "Must have working application link");
        assert.ok(o.eligibility, "Must have eligibility criteria");
      });
    });

    it("correctly identifies active vs expired opportunities against reference date 2026-11-03", () => {
      const opps = EduPrep.opportunities;
      const refNow = new Date("2026-11-03T12:00:00Z");

      const active = EduPrepServices.Opportunity.filterOpportunities(opps, { hideExpired: true, now: refNow });
      const expired = opps.filter(o => EduPrepServices.Opportunity.isExpired(o.deadlineDate, refNow));

      assert.ok(active.length > 0, "Must have active opportunities");
      assert.ok(expired.length >= 1, "Must have archived/expired opportunity for test validation");
      assert.equal(active.length + expired.length, opps.length, "Active + Expired must equal total count");
    });
  });

  // =========================================================================
  // 8. GLOBAL PUBLIC RESOURCE SEARCH
  // =========================================================================
  describe("Global Public Resource Search Across All Educational Dimensions", () => {
    it("searches subjects, chapters, notes, MCQs, flashcards, PYQs, and opportunities", () => {
      // 1. Subject exact search
      const osSearch = EduPrep.searchCurriculum("Operating Systems");
      assert.ok(osSearch.hasMatches);
      assert.ok(osSearch.subjects.some(s => s.title === "Operating Systems"));

      // 2. Academic alias search (e.g. 'dbms' -> Database Management Systems)
      const dbmsSearch = EduPrep.searchCurriculum("dbms");
      assert.ok(dbmsSearch.hasMatches);
      assert.ok(dbmsSearch.subjects.some(s => s.title === "Database Management Systems"));

      // 3. Chapter title search
      const chSearch = EduPrep.searchCurriculum("Process Scheduling");
      assert.ok(chSearch.hasMatches);
      assert.ok(chSearch.chapters.length > 0);

      // 4. Detailed notes / definitions search
      const defSearch = EduPrep.searchCurriculum("paging");
      assert.ok(defSearch.hasMatches);
      assert.ok(defSearch.notes.length > 0, "Must match detailed notes for 'paging'");

      // 5. Opportunities search
      const oppSearch = EduPrep.searchCurriculum("hackathon");
      assert.ok(oppSearch.hasMatches);
      assert.ok(oppSearch.opportunities.length > 0, "Must match hackathons");

      // 6. PYQ search
      const pyqSearch = EduPrep.searchCurriculum("2024");
      assert.ok(pyqSearch.hasMatches);
      assert.ok(pyqSearch.pyqs.length > 0, "Must match 2024 question papers");
    });

    it("returns direct, valid deep-links for search results", () => {
      const res = EduPrep.searchCurriculum("Operating Systems");
      assert.ok(res.allResults.length > 0);

      res.allResults.forEach((item) => {
        assert.ok(item.url, "Search result must have destination URL");
        assert.ok(!item.url.includes("undefined"), "URL must not contain undefined values");
      });
    });
  });

  // =========================================================================
  // 9. API SECURITY & SERVER STATUS MODULE
  // =========================================================================
  describe("API Security & Server Integration Status Endpoint", () => {
    it("exports api-status handler function", () => {
      assert.equal(typeof apiStatusHandler, "function");
    });

    it("reports honest integration status without leaking secret keys", async () => {
      const req = { method: "GET" };
      let statusCode = null;
      let bodyText = "";
      const res = {
        setHeader: () => {},
        set statusCode(c) { statusCode = c; },
        get statusCode() { return statusCode; },
        end: (b) => { bodyText = b; }
      };

      await apiStatusHandler(req, res);
      assert.equal(statusCode, 200);

      const json = JSON.parse(bodyText);
      assert.ok(json.timestamp);
      assert.ok(json.services);
      assert.ok(json.services.gemini);
      assert.ok(json.services.youtube);

      // Never expose actual secret strings
      assert.equal(bodyText.includes(process.env.GEMINI_API_KEY || "NEVER_EXPOSE"), false);
      assert.equal(bodyText.includes(process.env.YOUTUBE_API_KEY || "NEVER_EXPOSE"), false);

      // Status values must be safe human-readable strings
      assert.ok(["Connected", "Not configured", "Temporarily unavailable"].includes(json.services.gemini.status));
      assert.ok(["Connected", "Not configured", "Temporarily unavailable"].includes(json.services.youtube.status));
    });
  });

});
