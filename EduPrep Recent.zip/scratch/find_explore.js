const fs = require('fs');
const txt = fs.readFileSync('C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\index.html', 'utf8');
const lines = txt.split('\n');
lines.forEach((l, i) => {
  if (l.includes('Explore Resources')) {
    console.log(`${i+1}: ${l.trim()}`);
  }
});
