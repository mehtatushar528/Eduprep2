// ============================================================================
// EduPrep — Public Activities API Handler (api/activities.js)
// Serves /api/activities and child routes: /latest, /categories, /search,
// /deadlines, /calendar, /refresh-status, and /:id.
// Supports Vercel Serverless Function & Node.js HTTP server.
// ============================================================================

const store = require("./activities-store");

module.exports = async function handler(req, res) {
  // CORS & Security Headers
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("X-Content-Type-Options", "nosniff");

  if (req.method === "OPTIONS") {
    res.statusCode = 200;
    return res.end("ok");
  }

  if (req.method !== "GET") {
    res.statusCode = 405;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ error: "Method not allowed. Use GET." }));
  }

  const host = (req.headers && req.headers.host) || "localhost";
  const parsedUrl = new URL(req.url, `http://${host}`);
  let pathname = decodeURIComponent(parsedUrl.pathname);

  // Strip prefix variations: /api/activities.js -> /api/activities
  if (pathname.endsWith(".js")) {
    pathname = pathname.slice(0, -3);
  }

  // Extract sub-path after /api/activities
  let subPath = "";
  if (pathname.startsWith("/api/activities")) {
    subPath = pathname.slice("/api/activities".length).replace(/^\/+/, "");
  }

  const q = parsedUrl.searchParams;

  // 1. /api/activities/latest
  if (subPath === "latest") {
    const limit = parseInt(q.get("limit"), 10) || 6;
    const items = store.getLatest(limit);
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ success: true, count: items.length, items }));
  }

  // 2. /api/activities/categories
  if (subPath === "categories") {
    const categories = store.getCategories();
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ success: true, categories }));
  }

  // 3. /api/activities/deadlines
  if (subPath === "deadlines") {
    const deadlines = store.getDeadlines();
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ success: true, deadlines }));
  }

  // 4. /api/activities/calendar
  if (subPath === "calendar") {
    const year = q.get("year");
    const month = q.get("month");
    const calendarData = store.getCalendar({ year, month });
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ success: true, ...calendarData }));
  }

  // 5. /api/activities/refresh-status
  if (subPath === "refresh-status" || subPath === "status") {
    const statusData = store.getRefreshStatus();
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ success: true, ...statusData }));
  }

  // 6. /api/activities/search
  if (subPath === "search") {
    const query = q.get("q") || "";
    const category = q.get("category") || "all";
    const mode = q.get("mode") || "all";
    const deadline = q.get("deadline") || "all";
    const sort = q.get("sort") || "announcement";
    const page = parseInt(q.get("page"), 10) || 1;
    const limit = parseInt(q.get("limit"), 10) || 20;

    const result = store.getAll({ search: query, category, mode, deadline, sort, page, limit });
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ success: true, ...result }));
  }

  // 7. /api/activities/:id (Single Item Detail)
  if (subPath && !subPath.includes("/")) {
    const opp = store.getById(subPath);
    if (!opp) {
      res.statusCode = 404;
      res.setHeader("Content-Type", "application/json");
      return res.end(JSON.stringify({ error: `Opportunity with ID '${subPath}' not found.` }));
    }
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ success: true, opportunity: opp }));
  }

  // 8. Base: /api/activities (Full paginated feed with filters)
  const category = q.get("category") || "all";
  const search = q.get("search") || q.get("q") || "";
  const mode = q.get("mode") || "all";
  const deadline = q.get("deadline") || "all";
  const verification = q.get("verification") || "all";
  const isSample = q.get("isSample") || "all";
  const sort = q.get("sort") || "announcement";
  const page = parseInt(q.get("page"), 10) || 1;
  const limit = parseInt(q.get("limit"), 10) || 20;

  const result = store.getAll({ category, search, mode, deadline, verification, isSample, sort, page, limit });

  res.statusCode = 200;
  res.setHeader("Content-Type", "application/json");
  return res.end(JSON.stringify({
    success: true,
    lastRefreshedAt: store.lastRefreshedAt,
    ...result
  }));
};
