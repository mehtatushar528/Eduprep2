// ============================================================================
// EduPrep — Admin Activities API Handler (api/activities-admin.js)
// Internal management and background operations:
// POST /api/admin/activities/refresh
// POST /api/admin/activities/process-source
// GET  /api/admin/activities/source-status
// GET  /api/admin/activities/refresh-history
// ============================================================================

const store = require("./activities-store");
const { runScheduledRefresh, isJobRunning } = require("./activities-collector");
const { extractOpportunityWithGemini } = require("./activities-ai");

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("X-Content-Type-Options", "nosniff");

  if (req.method === "OPTIONS") {
    res.statusCode = 200;
    return res.end("ok");
  }

  const host = (req.headers && req.headers.host) || "localhost";
  const parsedUrl = new URL(req.url, `http://${host}`);
  let pathname = decodeURIComponent(parsedUrl.pathname);

  if (pathname.endsWith(".js")) {
    pathname = pathname.slice(0, -3);
  }

  let subPath = "";
  if (pathname.startsWith("/api/admin/activities")) {
    subPath = pathname.slice("/api/admin/activities".length).replace(/^\/+/, "");
  }

  // Parse JSON body if present for POST
  let body = req.body || {};
  if (typeof body === "string") {
    try {
      body = JSON.parse(body);
    } catch (_) {
      body = {};
    }
  }

  // 1. POST /api/admin/activities/refresh
  if (subPath === "refresh") {
    if (req.method !== "POST") {
      res.statusCode = 405;
      res.setHeader("Content-Type", "application/json");
      return res.end(JSON.stringify({ error: "Method not allowed. Use POST." }));
    }

    if (isJobRunning()) {
      res.statusCode = 409;
      res.setHeader("Content-Type", "application/json");
      return res.end(JSON.stringify({
        success: false,
        message: "Source collection job is already running in background."
      }));
    }

    const refreshResult = await runScheduledRefresh();
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify(refreshResult));
  }

  // 2. POST /api/admin/activities/process-source
  if (subPath === "process-source") {
    if (req.method !== "POST") {
      res.statusCode = 405;
      res.setHeader("Content-Type", "application/json");
      return res.end(JSON.stringify({ error: "Method not allowed. Use POST." }));
    }

    const sourceContent = typeof body.content === "string" ? body.content.trim() : "";
    const sourceUrl = typeof body.sourceUrl === "string" ? body.sourceUrl.trim() : "";

    if (!sourceContent) {
      res.statusCode = 400;
      res.setHeader("Content-Type", "application/json");
      return res.end(JSON.stringify({ error: "Please provide non-empty source content." }));
    }

    const extractionResult = await extractOpportunityWithGemini(sourceContent, sourceUrl);
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify(extractionResult));
  }

  // 3. GET /api/admin/activities/source-status
  if (subPath === "source-status") {
    const sources = store.getSources();
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({
      success: true,
      totalSources: sources.length,
      sources
    }));
  }

  // 4. GET /api/admin/activities/refresh-history
  if (subPath === "refresh-history") {
    const history = store.getRefreshHistory();
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({
      success: true,
      totalLogs: history.length,
      history
    }));
  }

  res.statusCode = 404;
  res.setHeader("Content-Type", "application/json");
  return res.end(JSON.stringify({ error: `Admin route '/api/admin/activities/${subPath}' not found.` }));
};
