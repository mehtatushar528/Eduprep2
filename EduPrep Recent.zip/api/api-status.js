// ============================================================================
// EduPrep — Centralized API Status & Validation Endpoint (/api/api-status)
// Reports safe operational status for external integrations (YouTube, Gemini, Supabase).
// CRITICAL: NEVER prints, exposes, or logs secret API keys or credentials.
// ============================================================================

module.exports = function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");

  if (req.method === "OPTIONS") {
    res.statusCode = 200;
    return res.end("ok");
  }

  const ytKey = process.env.YOUTUBE_API_KEY;
  const isYtConfigured = Boolean(
    ytKey &&
    ytKey !== "your-youtube-data-api-v3-key" &&
    ytKey !== "your_youtube_api_key" &&
    ytKey.length > 10
  );

  const geminiKey = process.env.GEMINI_API_KEY || process.env.AI_API_KEY;
  const isGeminiConfigured = Boolean(
    geminiKey &&
    geminiKey !== "your-server-side-ai-api-key" &&
    geminiKey !== "your_gemini_api_key" &&
    geminiKey.length > 10
  );

  const supabaseUrl = process.env.VITE_SUPABASE_URL;
  const isSupabaseConfigured = Boolean(
    supabaseUrl &&
    supabaseUrl.includes("supabase.co") &&
    !supabaseUrl.includes("your-project-ref")
  );

  const statusPayload = {
    app: process.env.VITE_APP_NAME || "EduPrep",
    timestamp: new Date().toISOString(),
    services: {
      youtube: {
        status: isYtConfigured ? "Connected" : "Not configured",
        provider: "YouTube Data API v3",
        quotaSafeCache: true,
      },
      gemini: {
        status: isGeminiConfigured ? "Connected" : "Not configured",
        provider: "Google Gemini AI",
        model: process.env.AI_MODEL || "gemini-flash-lite-latest",
        socraticTutorEnabled: isGeminiConfigured,
      },
      supabase: {
        status: isSupabaseConfigured ? "Connected" : "Not configured",
        openAccessMode: true,
      },
      activities: {
        status: "Active",
        provider: "EduPrep Real-time Opportunities Stream",
        geminiExtractorEnabled: isGeminiConfigured,
        autoSchedulerEnabled: true,
      },
    },
  };

  res.statusCode = 200;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(statusPayload, null, 2));
};
