const fs = require("fs");
const vm = require("vm");
const p = "./EduPrep/EduPrep/home_dashboard/code.html";
const content = fs.readFileSync(p, "utf8");
const inlineScriptRegex = /<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/gi;
let match;
let idx = 0;
while ((match = inlineScriptRegex.exec(content)) !== null) {
  idx++;
  if (idx === 2) {
    const lines = match[1].split("\n");
    for (let i = 1; i <= lines.length; i++) {
      const codeChunk = lines.slice(0, i).join("\n");
      try {
        new vm.Script(codeChunk);
      } catch (err) {
        if (!err.message.includes("Unexpected end of input")) {
          console.log(`Error at line ${i}: ${err.message}`);
          console.log(`Line ${i}: ${lines[i - 1]}`);
          console.log("Context:");
          for (let c = Math.max(0, i - 10); c < Math.min(lines.length, i + 10); c++) {
            console.log(`${c + 1}: ${lines[c]}`);
          }
          break;
        }
      }
    }
  }
}
