const fs = require("fs");
const path = require("path");
const vm = require("vm");

const sharedDir = path.resolve(__dirname, "../EduPrep/shared");

// Create a mock browser window environment
const store = {};
const mockWindow = {
  location: { href: "http://localhost:3000/", search: "", pathname: "/" },
  localStorage: {
    getItem: (k) => store[k] || null,
    setItem: (k, v) => { store[k] = String(v); },
    removeItem: (k) => { delete store[k]; },
    clear: () => { for (const k in store) delete store[k]; }
  },
  sessionStorage: {
    getItem: () => null,
    setItem: () => {},
    removeItem: () => {},
    clear: () => {}
  },
  document: {
    addEventListener: () => {},
    getElementById: () => null,
    querySelector: () => null,
    querySelectorAll: () => [],
    createElement: () => ({ style: {}, classList: { add: () => {}, remove: () => {} }, setAttribute: () => {} }),
    body: { appendChild: () => {}, style: {} }
  },
  navigator: { userAgent: "NodeTest" },
  console: console,
  setTimeout: setTimeout,
  clearTimeout: clearTimeout,
  setInterval: setInterval,
  clearInterval: clearInterval,
  fetch: async () => ({ ok: true, json: async () => ({}) })
};
mockWindow.window = mockWindow;
mockWindow.globalThis = mockWindow;

const context = vm.createContext(mockWindow);

const files = [
  "env_config.js",
  "supabase_client.js",
  "eduprep_services.js",
  "eduprep_chapters_data.js",
  "eduprep_video_engine.js",
  "eduprep_pyq_data.js",
  "eduprep_data.js",
  "eduvantage_data.js",
  "eduprep_chatbot.js"
];

for (const f of files) {
  const full = path.join(sharedDir, f);
  if (!fs.existsSync(full)) {
    console.error(`File missing: ${f}`);
    continue;
  }
  const code = fs.readFileSync(full, "utf8");
  try {
    vm.runInContext(code, context, { filename: f });
    console.log(`[PASS] Successfully executed ${f}`);
  } catch (err) {
    console.error(`[FAIL] Error executing ${f}:`, err);
  }
}

// Test EduPrep API
console.log("\n=== Verifying window.EduPrep APIs ===");
const EduPrep = mockWindow.EduPrep;
if (!EduPrep) {
  console.error("CRITICAL: window.EduPrep is not defined!");
} else {
  console.log("EduPrep.appName:", EduPrep.appName);
  console.log("EduPrep.streams:", EduPrep.streams ? EduPrep.streams.length : "undefined");
  console.log("EduPrep.universities:", EduPrep.universities ? EduPrep.universities.length : "undefined");
  console.log("EduPrep.colleges:", EduPrep.colleges ? EduPrep.colleges.length : "undefined");
  console.log("EduPrep.subjects:", EduPrep.subjects ? EduPrep.subjects.length : "undefined");

  const state = EduPrep.getState();
  console.log("EduPrep.getState():", state ? "Success" : "Failed");
}
