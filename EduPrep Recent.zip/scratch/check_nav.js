const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

function findHtml(dir) {
  let list = [];
  for (const f of fs.readdirSync(dir)) {
    const full = path.join(dir, f);
    if (fs.statSync(full).isDirectory()) list = list.concat(findHtml(full));
    else if (f.endsWith('.html')) list.push(full);
  }
  return list;
}

const htmls = findHtml(base);
htmls.forEach(h => {
  const rel = path.relative(base, h);
  const txt = fs.readFileSync(h, 'utf8');
  const hasPublicNav = /aria-label=["']Public Navigation["']|Home.*Features.*About/s.test(txt);
  const hasStudentNav = /Student Workspace/i.test(txt);
  const hasHomeLink = /href=["'][^"']*index\.html#home["']|href=["']#home["']/.test(txt);
  const hasFeaturesLink = /href=["'][^"']*index\.html#features["']|href=["']#features["']/.test(txt);
  const hasAboutLink = /href=["'][^"']*index\.html#about["']|href=["']#about["']/.test(txt);
  console.log(`${rel} -> PublicNav: ${hasPublicNav}, StudentWorkspace: ${hasStudentNav}, Home: ${hasHomeLink}, Feat: ${hasFeaturesLink}, About: ${hasAboutLink}`);
});
