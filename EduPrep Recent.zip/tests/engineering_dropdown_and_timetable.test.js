/**
 * Comprehensive Test Suite for Engineering Subject Dropdown Fix &
 * Customizable Exam Timetable with Personalized Study Planner
 */
const { describe, it, before, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

// Load EduPrep Core and Chapters Engine
require('../EduPrep/shared/eduprep_data.js');
require('../EduPrep/shared/eduprep_chapters_data.js');

function formatLocalDate(d) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

describe("Engineering Subject Dropdown Fix", () => {
  it("resolves canonical metadata for Engineering subjects and branch-specific variations", () => {
    const testCases = [
      { input: "Operating Systems", expectedId: "os" },
      { input: "Operating Systems Architecture", expectedId: "os" },
      { input: "Operating Systems with Linux", expectedId: "os" },
      { input: "ITC401", expectedId: "os" },
      { input: "CSC401", expectedId: "os" },
      { input: "Database Management Systems", expectedId: "dbms" },
      { input: "Database Management & NoSQL", expectedId: "dbms" },
      { input: "ITC403", expectedId: "dbms" },
      { input: "Computer Networks", expectedId: "computer_networks" },
      { input: "Computer Network Security", expectedId: "computer_networks" },
      { input: "Theory of Computation", expectedId: "theory_of_computation" },
      { input: "Automata Theory & Languages", expectedId: "theory_of_computation" },
      { input: "Web Technology", expectedId: "web_technology" },
      { input: "Web Development Frameworks", expectedId: "web_technology" },
      { input: "Machine Learning", expectedId: "machine_learning" },
      { input: "Machine Learning Fundamentals", expectedId: "machine_learning" },
      { input: "Cloud Computing", expectedId: "cloud_computing" },
      { input: "Cloud & DevOps", expectedId: "cloud_computing" },
      { input: "Engineering Mathematics I", expectedId: "eng_math" },
      { input: "Engineering Mathematics II", expectedId: "eng_math" }
    ];

    for (const tc of testCases) {
      const meta = EduPrepChapters.getSubjectMeta(tc.input);
      assert.ok(meta, `Metadata must be found for "${tc.input}"`);
      assert.equal(meta.id, tc.expectedId, `Subject "${tc.input}" must resolve to ID "${tc.expectedId}"`);
    }
  });

  it("loads non-empty chapters for Operating Systems Architecture and related variations", () => {
    const chOSArch = EduPrepChapters.getChapters("Operating Systems Architecture", 4);
    assert.ok(Array.isArray(chOSArch) && chOSArch.length > 0, "Chapters must be found for Operating Systems Architecture in sem 4");
    assert.equal(chOSArch.length, 6, "Must have exactly 6 chapters for Operating Systems Architecture");

    const chOSArchAll = EduPrepChapters.getChapters("Operating Systems Architecture");
    assert.ok(Array.isArray(chOSArchAll) && chOSArchAll.length > 0, "Chapters must load without semester specified");
    assert.equal(chOSArchAll.length, 6);

    const chDBMS = EduPrepChapters.getChapters("Database Management & NoSQL", 4);
    assert.ok(Array.isArray(chDBMS) && chDBMS.length > 0, "Chapters must be found for Database Management & NoSQL");

    const chNetworks = EduPrepChapters.getChapters("Computer Network Security", 4);
    assert.ok(Array.isArray(chNetworks) && chNetworks.length > 0, "Chapters must be found for Computer Network Security");
  });

  it("getSubjects strictly respects the requested semester and does NOT silently fall back to semester 4", () => {
    // Test branch 'it'
    const sem1Subs = EduPrep.getSubjects("it", 1);
    assert.ok(sem1Subs.length > 0, "Semester 1 must return subjects for IT");
    assert.ok(sem1Subs.some(s => s.name.includes("Mathematics")), "Semester 1 must contain Mathematics");
    assert.ok(!sem1Subs.some(s => s.name === "Operating Systems Architecture"), "Semester 1 must not contain Sem 4 OS Architecture");

    const sem4Subs = EduPrep.getSubjects("it", 4);
    assert.ok(sem4Subs.some(s => s.name === "Operating Systems Architecture"), "Semester 4 must contain OS Architecture for IT");

    const sem8Subs = EduPrep.getSubjects("it", 8);
    assert.ok(sem8Subs.length > 0, "Semester 8 must return subjects for IT");
    // MUST NOT return Semester 4 subjects
    assert.ok(!sem8Subs.some(s => s.name === "Operating Systems Architecture"), "Semester 8 must NEVER silently fall back to Sem 4 OS Architecture");
    assert.ok(!sem8Subs.some(s => s.name === "Computer Network Security"), "Semester 8 must not return Sem 4 Computer Network Security");

    // Test branch 'ce'
    const ceSem8 = EduPrep.getSubjects("ce", 8);
    assert.ok(ceSem8.some(s => s.name === "Major Project" || s.name === "Cloud & DevOps"), "CE Sem 8 must contain real Sem 8 subjects");
  });

  it("getStreamSubjects filters by semester when semesterNumber is provided, and returns all when omitted", () => {
    const allEngineering = EduPrep.getStreamSubjects("engineering");
    assert.equal(allEngineering.length, 25, "Must return all 25 Engineering subjects when semester is omitted");

    const sem1Engineering = EduPrep.getStreamSubjects("engineering", 1);
    assert.ok(sem1Engineering.length > 0 && sem1Engineering.length < 25, "Must filter Engineering subjects for Semester 1");
    assert.ok(sem1Engineering.includes("Engineering Physics"), "Sem 1 must include Engineering Physics");
    assert.ok(!sem1Engineering.includes("Cloud Computing"), "Sem 1 must not include Cloud Computing");

    const sem4Engineering = EduPrep.getStreamSubjects("engineering", 4);
    assert.ok(sem4Engineering.includes("Operating Systems"), "Sem 4 must include Operating Systems");
    assert.ok(sem4Engineering.includes("Database Management Systems"), "Sem 4 must include Database Management Systems");
    assert.ok(!sem4Engineering.includes("Engineering Physics"), "Sem 4 must not include Engineering Physics");

    const sem8Engineering = EduPrep.getStreamSubjects("engineering", 8);
    assert.ok(sem8Engineering.includes("Cloud Computing"), "Sem 8 must include Cloud Computing");
    assert.ok(!sem8Engineering.includes("Engineering Physics"), "Sem 8 must not include Engineering Physics");
  });

  it("does not leak subjects across academic streams", () => {
    const eng = EduPrep.getStreamSubjects("engineering");
    const med = EduPrep.getStreamSubjects("medical");
    const com = EduPrep.getStreamSubjects("commerce");
    const art = EduPrep.getStreamSubjects("arts");

    for (const s of med) assert.equal(eng.includes(s), false, `Engineering must not contain medical subject: ${s}`);
    for (const s of com) assert.equal(eng.includes(s), false, `Engineering must not contain commerce subject: ${s}`);
    for (const s of art) assert.equal(eng.includes(s), false, `Engineering must not contain arts subject: ${s}`);
  });
});

describe("Customizable Exam Timetable and Personalized Study Planner", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it("generates default verified exam timetable when no custom timetable is saved", () => {
    const defaultTimetable = EduPrep.getExamTimetable(4);
    assert.ok(Array.isArray(defaultTimetable), "Must return an array of exams");
    assert.ok(defaultTimetable.length >= 5, "Must contain default exams for active semester subjects");
    assert.ok(defaultTimetable[0].examDate, "Exam entry must have an examDate");
    assert.ok(defaultTimetable[0].startTime, "Exam entry must have a startTime");
    assert.ok(defaultTimetable[0].endTime, "Exam entry must have an endTime");
    assert.ok(defaultTimetable[0].duration, "Exam entry must have a duration");
    assert.equal(defaultTimetable[0].isDefault, true, "Must be flagged as default timetable");
  });

  it("saves, retrieves, and sorts custom exam timetable chronologically", () => {
    const customExams = [
      {
        subject: "Computer Networks",
        subjectCode: "CSC402",
        examDate: "2026-05-25",
        startTime: "11:00 AM",
        endTime: "02:00 PM",
        examType: "Theory Examination (80 Marks)",
        venue: "Hall 201"
      },
      {
        subject: "Operating Systems",
        subjectCode: "CSC401",
        examDate: "2026-05-18",
        startTime: "11:00 AM",
        endTime: "02:00 PM",
        examType: "Theory Examination (80 Marks)",
        venue: "Hall 101"
      }
    ];

    EduPrep.saveExamTimetable(4, customExams);

    const loaded = EduPrep.getExamTimetable(4);
    assert.equal(loaded.length, 2);
    // Must be sorted chronologically: 2026-05-18 first, then 2026-05-25
    assert.equal(loaded[0].subject, "Operating Systems");
    assert.equal(loaded[0].examDate, "2026-05-18");
    assert.equal(loaded[1].subject, "Computer Networks");
    assert.equal(loaded[1].examDate, "2026-05-25");
    assert.equal(loaded[0].isDefault, false);
  });

  it("maintains strict semester separation for exam timetables", () => {
    const sem2Exams = [
      { subject: "Engineering Mathematics II", examDate: "2026-06-10", startTime: "10:00 AM", endTime: "01:00 PM" }
    ];
    const sem5Exams = [
      { subject: "Design & Analysis of Algorithms", examDate: "2026-11-20", startTime: "11:00 AM", endTime: "02:00 PM" }
    ];

    EduPrep.saveExamTimetable(2, sem2Exams);
    EduPrep.saveExamTimetable(5, sem5Exams);

    const loadedSem2 = EduPrep.getExamTimetable(2);
    const loadedSem5 = EduPrep.getExamTimetable(5);

    assert.equal(loadedSem2.length, 1);
    assert.equal(loadedSem2[0].subject, "Engineering Mathematics II");

    assert.equal(loadedSem5.length, 1);
    assert.equal(loadedSem5[0].subject, "Design & Analysis of Algorithms");
  });

  it("calculates countdown and upcoming exam summary accurately", () => {
    // Schedule one exam 10 days in future using local date
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 10);
    const dateStr = formatLocalDate(futureDate);

    const exams = [
      { subject: "Operating Systems", subjectCode: "CSC401", examDate: dateStr, startTime: "11:00 AM", endTime: "02:00 PM" }
    ];

    EduPrep.saveExamTimetable(4, exams);
    const summary = EduPrep.getUpcomingExamSummary(4);

    assert.equal(summary.hasExams, true);
    assert.equal(summary.daysRemaining, 10);
    assert.equal(summary.daysText, "10");
    assert.equal(summary.upcomingCount, 1);
    assert.ok(summary.displayLabel.includes("Operating Systems"));
  });

  it("generates personalized study plan with chapters in the Study Planner storage", () => {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 14);
    const dateStr = formatLocalDate(futureDate);

    const exams = [
      { subject: "Operating Systems", subjectCode: "CSC401", examDate: dateStr, startTime: "11:00 AM", endTime: "02:00 PM" }
    ];

    EduPrep.saveExamTimetable(4, exams);
    const result = EduPrep.generatePersonalizedStudyPlan(4, exams);

    assert.ok(result.generatedCount > 0, "Must generate study targets");
    
    // Check Study Planner storage key
    const rawPlans = localStorage.getItem("eduprep_study_plans_v1_sem4");
    assert.ok(rawPlans, "Study planner storage key for sem 4 must exist");
    const plans = JSON.parse(rawPlans);
    assert.ok(plans.length >= 6, "Must contain targets for Operating Systems chapters");
    assert.ok(plans.some(p => p.subject === "Operating Systems"));
    assert.ok(plans[0].dueDate <= dateStr, "Due dates must be before or on the exam date");
  });

  it("resets timetable cleanly back to default syllabus schedule", () => {
    EduPrep.saveExamTimetable(4, [{ subject: "Custom Test Exam", examDate: "2026-12-01" }]);
    assert.equal(EduPrep.getExamTimetable(4).length, 1);

    EduPrep.resetExamTimetable(4);
    const resetList = EduPrep.getExamTimetable(4);
    assert.ok(resetList.length >= 5, "Must restore default syllabus exams");
    assert.equal(resetList[0].isDefault, true);
  });
});
