const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

['affiliated_college_selection/code.html', 'login_registration/code.html'].forEach(p => {
  const full = path.join(base, p);
  const txt = fs.readFileSync(full, 'utf8');
  const m = txt.match(/<header[\s\S]*?<\/header>/);
  console.log(`=== ${p} ===`);
  if (m) console.log(m[0]);
});
