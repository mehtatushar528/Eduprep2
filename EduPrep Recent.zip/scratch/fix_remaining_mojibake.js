const fs = require('fs');
const path = require('path');

const fileFixes = [
  {
    rel: 'EduPrep/EduPrep/academic_setup/code.html',
    replacements: [
      { from: /Done âœ“/g, to: 'Done ✓' }
    ]
  },
  {
    rel: 'EduPrep/EduPrep/activities/code.html',
    replacements: [
      { from: /Selected ðŸŽ‰/g, to: 'Selected 🎉' },
      { from: /â ° /g, to: '⏰ ' },
      { from: /ðŸ“… /g, to: '📅 ' },
      { from: /Enabled âœ“/g, to: 'Enabled ✓' }
    ]
  },
  {
    rel: 'EduPrep/EduPrep/home_dashboard/code.html',
    replacements: [
      { from: /ðŸ‘‹/g, to: '👋' }
    ]
  },
  {
    rel: 'EduPrep/EduPrep/index.html',
    replacements: [
      { from: /Â©/g, to: '©' }
    ]
  },
  {
    rel: 'EduPrep/EduPrep/shared/eduprep_data.js',
    replacements: [
      { from: /âˆˆ/g, to: '∈' },
      { from: /nÂ²/g, to: 'n²' },
      { from: /Ïƒ/g, to: 'σ' },
      { from: /Ï€/g, to: 'π' },
      { from: /Ï /g, to: 'ρ' },
      { from: /âˆª/g, to: '∪' },
      { from: /âœ•/g, to: '✕' },
      { from: /â‹ˆ/g, to: '⋈' }
    ]
  }
];

const root = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent';

fileFixes.forEach(item => {
  const full = path.join(root, item.rel);
  let content = fs.readFileSync(full, 'utf8');
  item.replacements.forEach(r => {
    content = content.replace(r.from, r.to);
  });
  fs.writeFileSync(full, content, 'utf8');
  console.log('Fixed:', item.rel);
});

console.log('All remaining fixes applied successfully.');
