const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

const secondary = [
  'questions_practice/code.html',
  'subject_details/code.html',
  'subject_details_os/code.html',
  'student_opportunities/code.html',
  'study_ai_assistant/code.html',
  'admin_panel/code.html',
  'affiliated_college_selection/code.html',
  'ai_tutor_personality_setup/code.html',
  'login_registration/code.html',
  'academic_setup_updated_flow/code.html',
  '404.html'
];

secondary.forEach(p => {
  const full = path.join(base, p);
  const txt = fs.readFileSync(full, 'utf8');
  const m = txt.match(/<header[\s\S]*?<\/header>/);
  console.log(`\n=================== ${p} ===================`);
  if (m) console.log(m[0].slice(0, 500) + '...\n' + m[0].slice(-200));
  else console.log('NO <header>');
});
