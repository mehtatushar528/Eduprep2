const fs = require('fs');

const files = [
  'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\previous_year_papers\\code.html',
  'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\home_dashboard\\code.html',
  'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\index.html',
  'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\activities\\code.html',
  'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\academic_setup\\code.html',
  'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\shared\\eduprep_data.js',
  'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep\\user_profile_progress\\code.html'
];

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  const lines = content.split('\n');
  console.log(`\n=== Checking: ${file.split('\\').slice(-2).join('/')} ===`);
  lines.forEach((line, idx) => {
    // Look for â, \uFFFD, or suspicious multi-byte artifacts
    if (/[\u00C2\u00C3\u00E2\uFFFD]/.test(line) || /â/.test(line)) {
      console.log(`L${idx + 1}: ${line.trim()}`);
    }
  });
}
