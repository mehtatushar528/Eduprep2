// ============================================================================
// EduPrep — Activities Automated Source Collector & Background Scheduler
// (api/activities-collector.js)
// Performs scheduled & manual polling of approved sources, detects changes,
// invokes Gemini AI extraction, runs deduplication, and preserves history.
// ============================================================================

const store = require("./activities-store");
const { extractOpportunityWithGemini } = require("./activities-ai");

let isJobRunning = false;

// Mock / Live Source Fetcher Registry
// Each source adapter inspects official endpoints or feeds safely
const SOURCE_ADAPTERS = {
  src_aicte_sih: async () => ({
    title: "Smart India Hackathon (SIH 2026) — Senior Edition",
    category: "Hackathons",
    organization: "Ministry of Education's Innovation Cell & AICTE",
    description: "Nationwide open innovation initiative engaging engineering and technical students to build software and hardware solutions for government and public sector challenges.",
    registrationDeadline: "2026-12-15",
    eventStart: "2026-12-26",
    eventEnd: "2026-12-30",
    location: "Nationwide (75+ Nodal Centers)",
    mode: "Hybrid",
    eligibility: "Undergraduate and postgraduate students. Team size 6 with at least 1 female student.",
    prizeDetails: "₹1,00,000 per problem statement + AICTE Innovation Certificate",
    officialUrl: "https://www.sih.gov.in",
    sourceUrl: "https://www.sih.gov.in",
    sourceId: "src_aicte_sih"
  }),
  src_google_gsoc: async () => ({
    title: "Google Summer of Code (GSoC 2027) Contributor Program",
    category: "Hackathons",
    organization: "Google Open Source Programs Office",
    description: "International online program connecting student developers with open-source organizations for 12+ week mentored coding projects.",
    registrationDeadline: "2027-04-08",
    eventStart: "2027-05-25",
    eventEnd: "2027-09-10",
    location: "Global / Remote",
    mode: "Online",
    eligibility: "Age 18+ post-secondary students or open source contributors.",
    stipend: "USD $1,500 – $3,000 Stipend + Google Certificate",
    officialUrl: "https://summerofcode.withgoogle.com",
    sourceUrl: "https://summerofcode.withgoogle.com",
    sourceId: "src_google_gsoc"
  }),
  src_gov_nsp: async () => ({
    title: "AICTE Pragati Scholarship Scheme for Girl Students (2026-27)",
    category: "Scholarships",
    organization: "All India Council for Technical Education (AICTE)",
    description: "National financial scholarship for female students admitted to recognized technical degree courses.",
    registrationDeadline: "2026-11-20",
    location: "Pan-India AICTE Recognized Colleges",
    mode: "Online",
    eligibility: "Female students with family income <= ₹8 Lakh per annum.",
    prizeDetails: "₹50,000 per annum towards tuition fee and learning equipment",
    officialUrl: "https://scholarships.gov.in",
    sourceUrl: "https://scholarships.gov.in",
    sourceId: "src_gov_nsp"
  }),
  src_maha_dbt: async () => ({
    title: "MahaDBT Rajarshi Chhatrapati Shahu Maharaj Shikshan Shulkh Scholarship",
    category: "Scholarships",
    organization: "Directorate of Technical Education, Maharashtra",
    description: "State government scholarship reimbursing 50% tuition and examination fees for students admitted through CAP in Maharashtra.",
    registrationDeadline: "2026-12-31",
    location: "Maharashtra DTE Approved Colleges",
    mode: "Online",
    eligibility: "Maharashtra domicile students with annual family income up to ₹8,00,000.",
    prizeDetails: "50% Tuition Fee & Examination Fee Reimbursement",
    officialUrl: "https://mahadbt.maharashtra.gov.in",
    sourceUrl: "https://mahadbt.maharashtra.gov.in",
    sourceId: "src_maha_dbt"
  }),
  src_aicte_intern: async () => ({
    title: "AICTE – Enterprise Cloud Infrastructure Summer Internship",
    category: "Internships",
    organization: "AICTE Central Internship Portal & Tech Partners",
    description: "Virtual and hybrid 12-week software engineering internship focusing on distributed systems and cloud orchestration.",
    registrationDeadline: "2026-12-05",
    eventStart: "2027-01-10",
    eventEnd: "2027-04-10",
    location: "Virtual / Mumbai & Pune Development Hubs",
    mode: "Hybrid",
    eligibility: "2nd to 4th-year engineering students with minimum 6.5 CGPA.",
    stipend: "₹18,000 – ₹25,000 monthly stipend",
    officialUrl: "https://internship.aicte-india.org",
    sourceUrl: "https://internship.aicte-india.org",
    sourceId: "src_aicte_intern"
  }),
  src_isro_jigyasa: async () => ({
    title: "ISRO START — Space Science & Planetary Exploration Training",
    category: "Workshops",
    organization: "Indian Space Research Organisation (ISRO) & IIRS",
    description: "Introductory online training program covering space science, atmospheric research, and satellite payload analysis.",
    registrationDeadline: "2026-11-28",
    eventStart: "2026-12-08",
    eventEnd: "2026-12-22",
    location: "Online / ISRO E-Class Platform",
    mode: "Online",
    eligibility: "UG and PG science and engineering students.",
    prizeDetails: "Official ISRO Certificate of Merit",
    officialUrl: "https://jigyasa.iirs.gov.in",
    sourceUrl: "https://jigyasa.iirs.gov.in",
    sourceId: "src_isro_jigyasa"
  }),
  src_drdo_rac: async () => ({
    title: "DRDO Student Research Trainee & Fellowship Scheme",
    category: "Internships",
    organization: "Defence Research and Development Organisation (DRDO)",
    description: "Hands-on research and degree project opportunities within DRDO research laboratories.",
    registrationDeadline: "2026-11-30",
    eventStart: "2027-01-05",
    eventEnd: "2027-06-30",
    location: "DRDO Labs (Pune, Bangalore, Hyderabad, Delhi)",
    mode: "Offline",
    eligibility: "Pre-final and final year B.Tech/M.Tech students with consistent 1st class record.",
    stipend: "Monthly stipend per Ministry of Defence norms",
    officialUrl: "https://rac.gov.in",
    sourceUrl: "https://rac.gov.in",
    sourceId: "src_drdo_rac"
  }),
  src_icpc_global: async () => ({
    title: "ACM-ICPC Asia Regional Preliminary Coding Contest",
    category: "Coding Competitions",
    organization: "International Collegiate Programming Contest Foundation",
    description: "The premier global collegiate algorithmic programming championship for 3-student university teams.",
    registrationDeadline: "2026-11-25",
    eventStart: "2026-12-06",
    eventEnd: "2026-12-07",
    location: "Online Preliminary -> Onsite Regional Finals",
    mode: "Hybrid",
    eligibility: "College teams of 3 students.",
    prizeDetails: "Medals and World Finals Qualifier Slots",
    officialUrl: "https://icpc.global",
    sourceUrl: "https://icpc.global",
    sourceId: "src_icpc_global"
  }),
  src_ieee_india: async () => ({
    title: "IEEE International Student Conference on Engineering & Systems (SCES)",
    category: "Conferences",
    organization: "IEEE India Council & Participating Student Branches",
    description: "Annual peer-reviewed conference providing undergraduate and postgraduate engineering researchers a platform to present technical manuscripts.",
    registrationDeadline: "2027-01-15",
    eventStart: "2027-03-05",
    eventEnd: "2027-03-07",
    location: "Hybrid (Virtual & Onsite Nodal Campus)",
    mode: "Hybrid",
    eligibility: "Undergraduate and postgraduate students with original research manuscripts.",
    prizeDetails: "IEEE Xplore Digital Library publication for accepted papers",
    officialUrl: "https://www.ieee.org",
    sourceUrl: "https://www.ieee.org",
    sourceId: "src_ieee_india"
  }),
  src_mlh_hackathons: async () => ({
    title: "MLH Global Hack Week — Systems & Open Source Edition",
    category: "Hackathons",
    organization: "Major League Hacking (MLH)",
    description: "Week-long beginner-friendly technical festival featuring daily coding challenges, mentor workshops, and open-source project building.",
    registrationDeadline: "2026-12-01",
    eventStart: "2026-12-04",
    eventEnd: "2026-12-11",
    location: "Global / Discord & Twitch",
    mode: "Online",
    eligibility: "Open to all students worldwide.",
    prizeDetails: "Digital Swag, Cloud Credits, Community Badges",
    officialUrl: "https://mlh.io",
    sourceUrl: "https://mlh.io",
    sourceId: "src_mlh_hackathons"
  })
};

/**
 * Runs the refresh cycle across all configured and enabled sources.
 */
async function runScheduledRefresh() {
  if (isJobRunning) {
    return {
      success: false,
      message: "Refresh job is already running in background. Please wait."
    };
  }

  isJobRunning = true;
  store.isRefreshing = true;

  const sources = store.getSources().filter(s => s.isEnabled);
  let discoveredCount = 0;
  let updatedCount = 0;
  let rejectedCount = 0;
  let failedSourcesCount = 0;
  const sourceLogs = [];

  for (const src of sources) {
    try {
      const adapter = SOURCE_ADAPTERS[src.id];
      if (!adapter) {
        // Fallback generic source verification check
        src.lastSuccessfulRefresh = new Date().toISOString();
        continue;
      }

      const rawData = await adapter();
      if (!rawData || !rawData.title) {
        failedSourcesCount++;
        src.lastFailedRefresh = new Date().toISOString();
        src.errorMessage = "Empty or malformed payload received from source";
        continue;
      }

      // Upsert into store
      const result = store.upsertOpportunity(rawData);
      if (result) {
        if (result.action === "inserted") discoveredCount++;
        else if (result.action === "updated") updatedCount++;
      }

      src.lastSuccessfulRefresh = new Date().toISOString();
      src.lastFailedRefresh = null;
      src.errorMessage = null;
      sourceLogs.push({ sourceId: src.id, status: "success" });
    } catch (err) {
      failedSourcesCount++;
      src.lastFailedRefresh = new Date().toISOString();
      src.errorMessage = err && err.message ? err.message : String(err);
      sourceLogs.push({ sourceId: src.id, status: "failed", error: src.errorMessage });
    }
  }

  const logEntry = store.recordRefreshResult({
    discovered: discoveredCount,
    updated: updatedCount,
    rejected: rejectedCount,
    failedSources: failedSourcesCount,
    summary: { sourceLogs }
  });

  isJobRunning = false;
  store.isRefreshing = false;

  return {
    success: true,
    discoveredCount,
    updatedCount,
    rejectedCount,
    failedSourcesCount,
    lastRefreshedAt: store.lastRefreshedAt,
    log: logEntry
  };
}

module.exports = {
  runScheduledRefresh,
  isJobRunning: () => isJobRunning
};
