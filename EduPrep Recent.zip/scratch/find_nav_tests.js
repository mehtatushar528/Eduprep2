const fs = require('fs');
const txt = fs.readFileSync('C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\tests\\eduprep.test.js', 'utf8');
const lines = txt.split('\n');
lines.forEach((l, i) => {
  if (l.includes('nav') || l.includes('Home') || l.includes('header') || l.includes('navigation') || l.includes('Student Workspace')) {
    console.log(`${i+1}: ${l.trim()}`);
  }
});
