const fs = require('fs');
const path = require('path');
const base = 'C:\\Users\\TUSHAR\\OneDrive\\Desktop\\EduPrep Recent\\EduPrep\\EduPrep';

const pages = [
  'home_dashboard/code.html',
  'previous_year_papers/code.html',
  'academic_setup/code.html',
  'activities/code.html',
  'user_profile_progress/code.html',
  'mcq_practice_exam/code.html',
  'revision_flashcards/code.html',
  'resources_dashboard/code.html'
];

pages.forEach(p => {
  const full = path.join(base, p);
  const txt = fs.readFileSync(full, 'utf8');
  const lines = txt.split('\n');
  const headerIdx = lines.findIndex(l => l.includes('<header'));
  const row1EndIdx = lines.findIndex((l, i) => i > headerIdx && l.includes('Student Workspace Quick-Bar'));
  console.log(`=== ${p} Row 1 (lines ${headerIdx+1} - ${row1EndIdx+1}) ===`);
  console.log(lines.slice(headerIdx, row1EndIdx > 0 ? row1EndIdx : headerIdx + 30).join('\n'));
});
