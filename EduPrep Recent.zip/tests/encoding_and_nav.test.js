const { describe, it } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");

const eduPrepDir = path.join(__dirname, "..", "EduPrep");

describe("EduPrep Website-Wide Text Encoding & Permanent Navigation Audit", () => {
  const htmlFiles = [
    "index.html",
    "home_dashboard/code.html",
    "previous_year_papers/code.html",
    "academic_setup/code.html",
    "activities/code.html",
    "user_profile_progress/code.html",
    "mcq_practice_exam/code.html",
    "revision_flashcards/code.html",
    "resources_dashboard/code.html",
    "student_opportunities/code.html",
    "admin_panel/code.html",
    "affiliated_college_selection/code.html",
    "ai_tutor_personality_setup/code.html",
    "academic_setup_updated_flow/code.html",
    "login_registration/code.html"
  ];

  it("ensures zero mojibake or encoding corruption artifacts across all HTML and JS files", () => {
    const mojibakeRegex = /[ÃÂâðÏ\uFFFD]/;
    const errors = [];

    function scanDir(dir) {
      for (const file of fs.readdirSync(dir)) {
        const full = path.join(dir, file);
        const stat = fs.statSync(full);
        if (stat.isDirectory()) {
          if (!["node_modules", ".git", "scratch", ".system_generated"].includes(file)) {
            scanDir(full);
          }
        } else if (/\.(html|js|json)$/.test(file)) {
          const content = fs.readFileSync(full, "utf8");
          const lines = content.split("\n");
          lines.forEach((line, idx) => {
            if (mojibakeRegex.test(line)) {
              errors.push(`${path.relative(eduPrepDir, full)}:${idx + 1} -> ${line.trim()}`);
            }
          });
        }
      }
    }

    scanDir(eduPrepDir);
    assert.deepEqual(errors, [], `Found unexpected mojibake artifacts:\n${errors.slice(0, 10).join("\n")}`);
  });

  it("ensures every main view page includes permanent Public Navigation (Home, Features, About)", () => {
    for (const rel of htmlFiles) {
      const full = path.join(eduPrepDir, rel);
      assert.ok(fs.existsSync(full), `File must exist: ${rel}`);
      const content = fs.readFileSync(full, "utf8");

      // Verify Public Navigation exists
      const hasPublicNav = /aria-label=["']Public Navigation["']/i.test(content);
      assert.ok(hasPublicNav, `Expected Public Navigation bar in ${rel}`);

      // Verify Home, Features, About are present
      assert.ok(content.includes(">Home<"), `Expected Home link in ${rel}`);
      assert.ok(content.includes(">Features<"), `Expected Features link in ${rel}`);
      assert.ok(content.includes(">About<"), `Expected About link in ${rel}`);

      // Verify href targets
      if (rel === "index.html") {
        assert.ok(content.includes('href="#home"'), "index.html must link to #home");
        assert.ok(content.includes('href="#features"'), "index.html must link to #features");
        assert.ok(content.includes('href="#about"'), "index.html must link to #about");
      } else {
        assert.ok(content.includes('href="../index.html#home"'), `${rel} must link to ../index.html#home`);
        assert.ok(content.includes('href="../index.html#features"'), `${rel} must link to ../index.html#features`);
        assert.ok(content.includes('href="../index.html#about"'), `${rel} must link to ../index.html#about`);
      }
    }
  });

  it("preserves Student Workspace navigation separate from Public Navigation on core workspace pages", () => {
    const coreWorkspacePages = [
      "index.html",
      "home_dashboard/code.html",
      "previous_year_papers/code.html",
      "academic_setup/code.html",
      "activities/code.html",
      "user_profile_progress/code.html",
      "mcq_practice_exam/code.html",
      "revision_flashcards/code.html",
      "resources_dashboard/code.html"
    ];

    for (const rel of coreWorkspacePages) {
      const full = path.join(eduPrepDir, rel);
      const content = fs.readFileSync(full, "utf8");

      assert.ok(content.includes("Student Workspace:"), `Expected Student Workspace quick-bar in ${rel}`);
      assert.ok(/aria-label=["']Student Navigation["']/i.test(content), `Expected Student Navigation bar in ${rel}`);
    }
  });

  it("verifies index.html has matching section targets for all public navigation links", () => {
    const indexContent = fs.readFileSync(path.join(eduPrepDir, "index.html"), "utf8");
    assert.ok(indexContent.includes('id="home"'), "index.html must contain id='home'");
    assert.ok(indexContent.includes('id="features"'), "index.html must contain id='features'");
    assert.ok(indexContent.includes('id="about"'), "index.html must contain id='about'");
  });
});
