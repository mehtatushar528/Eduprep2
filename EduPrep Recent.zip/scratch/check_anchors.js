const fs = require('fs');
const txt = fs.readFileSync('C:/Users/TUSHAR/OneDrive/Desktop/EduPrep Recent/EduPrep/EduPrep/index.html', 'utf8');
console.log('has #home:', txt.includes('id="home"'));
console.log('has #features:', txt.includes('id="features"'));
console.log('has #about:', txt.includes('id="about"'));
