const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");

function getHtmlFiles(dir) {
  let files = [];
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, item.name);
    if (item.isDirectory()) {
      if (item.name === "node_modules" || item.name === ".git") continue;
      files = files.concat(getHtmlFiles(full));
    } else if (item.name.endsWith(".html")) {
      files.push(full);
    }
  }
  return files;
}

const htmlFiles = getHtmlFiles(root);
const aHrefRegex = /<a\s+[^>]*href=["']([^"']+)["'][^>]*>/gi;

let issues = 0;

for (const htmlFile of htmlFiles) {
  const content = fs.readFileSync(htmlFile, "utf8");
  const rel = path.relative(root, htmlFile);
  const dir = path.dirname(htmlFile);

  let match;
  while ((match = aHrefRegex.exec(content)) !== null) {
    const href = match[1];
    // ignore external links, javascript:, #, mailto:, tel:
    if (
      href.startsWith("http://") ||
      href.startsWith("https://") ||
      href.startsWith("//") ||
      href.startsWith("javascript:") ||
      href.startsWith("mailto:") ||
      href.startsWith("tel:") ||
      href.startsWith("#") ||
      href.includes("${") // dynamic template string in JS
    ) {
      continue;
    }

    const cleanHref = href.split("?")[0].split("#")[0];
    if (!cleanHref) continue;

    let resolved;
    if (cleanHref.startsWith("/")) {
      resolved = path.join(root, "EduPrep", cleanHref);
      if (!fs.existsSync(resolved)) {
        resolved = path.join(root, cleanHref);
      }
    } else {
      resolved = path.resolve(dir, cleanHref);
    }

    // Also check if directory exists with code.html or index.html
    let exists = fs.existsSync(resolved);
    if (exists && fs.statSync(resolved).isDirectory()) {
      exists = fs.existsSync(path.join(resolved, "code.html")) || fs.existsSync(path.join(resolved, "index.html"));
    }

    if (!exists) {
      console.log(`[BROKEN A HREF] In ${rel}: href="${href}" -> resolved to ${resolved}`);
      issues++;
    }
  }
}

console.log("A HREF Scan finished. Total broken links: " + issues);
