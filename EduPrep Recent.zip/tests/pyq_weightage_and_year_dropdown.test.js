const { test, describe, before, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');

// Mock localStorage
const store = {};
global.localStorage = {
  getItem: (key) => (key in store ? store[key] : null),
  setItem: (key, val) => { store[key] = String(val); },
  removeItem: (key) => { delete store[key]; },
  clear: () => { Object.keys(store).forEach(k => delete store[k]); }
};

// Load EduPrep shared modules
const eduprepDataPath = path.resolve(__dirname, '../EduPrep/shared/eduprep_data.js');
const eduprepChaptersPath = path.resolve(__dirname, '../EduPrep/shared/eduprep_chapters_data.js');
const eduprepPyqPath = path.resolve(__dirname, '../EduPrep/shared/eduprep_pyq_data.js');

require(eduprepDataPath);
require(eduprepChaptersPath);
require(eduprepPyqPath);

describe('EduPrep PYQ Archives: Dynamic Examination Year & Weightage Allocation Suite', () => {

  const pyqEngine = global.EduPrepPyqs || (global.EduPrep && global.EduPrep.pyqEngine);

  test('TEST 1: pyqEngine is loaded and accessible', () => {
    assert.ok(pyqEngine, 'EduPrepPyqs must be defined on global/window');
    assert.strictEqual(typeof pyqEngine.getAvailableExamYears, 'function');
    assert.strictEqual(typeof pyqEngine.getPapersForSubject, 'function');
    assert.strictEqual(typeof pyqEngine.calculateWeightage, 'function');
  });

  test('TEST 2: getAvailableExamYears returns descending available years for subject', () => {
    // Operating Systems has real papers from 2024 and 2023, plus 2022 syllabus reference
    const osYears = pyqEngine.getAvailableExamYears('Operating Systems');
    assert.ok(Array.isArray(osYears), 'Must return an array of years');
    assert.deepStrictEqual(osYears, ['2024', '2023', '2022'], 'OS should provide 2024, 2023, 2022');

    // Analysis of Algorithms has 2024, 2023, 2022 papers
    const aoaYears = pyqEngine.getAvailableExamYears('Analysis of Algorithms');
    assert.deepStrictEqual(aoaYears, ['2024', '2023', '2022']);

    // Engineering Mathematics has standard archive 2024, 2023, 2022
    const mathYears = pyqEngine.getAvailableExamYears('Engineering Mathematics');
    assert.deepStrictEqual(mathYears, ['2024', '2023', '2022']);

    // Check descending order
    for (let i = 0; i < mathYears.length - 1; i++) {
      assert.ok(parseInt(mathYears[i], 10) > parseInt(mathYears[i + 1], 10), 'Years must be sorted descending');
    }
  });

  test('TEST 3: Single examination year returns single paper marks (80 M, NOT 240 M)', () => {
    const papers2024 = pyqEngine.getPapersForSubject('Engineering Mathematics', 'all', '2024');
    assert.strictEqual(papers2024.length, 1, 'Should return exactly 1 paper for 2024');
    assert.strictEqual(papers2024[0].year, '2024');

    const weightage2024 = pyqEngine.calculateWeightage(papers2024, 'all', '2024');
    assert.strictEqual(weightage2024.isAggregate, false, 'Single year must not be aggregate');
    assert.strictEqual(weightage2024.selectedYear, '2024');
    assert.strictEqual(weightage2024.totalPaperMarks, 80, 'Single year paper marks must be 80 M (not 240 M)');
    assert.strictEqual(weightage2024.totalMarks, 80);
    assert.strictEqual(weightage2024.verifiedPapersCount, 1);
  });

  test('TEST 4: All Years (Aggregate) returns sum of paper marks and aggregate flag', () => {
    const allPapers = pyqEngine.getPapersForSubject('Engineering Mathematics', 'all', 'all');
    assert.strictEqual(allPapers.length, 3, 'Should return 3 papers (2024, 2023, 2022)');

    const weightageAll = pyqEngine.calculateWeightage(allPapers, 'all', 'all');
    assert.strictEqual(weightageAll.isAggregate, true, 'All years must be aggregate');
    assert.strictEqual(weightageAll.selectedYear, 'all');
    assert.strictEqual(weightageAll.totalPaperMarks, 240, '3 papers of 80 M must equal 240 M in aggregate');
    assert.strictEqual(weightageAll.verifiedPapersCount, 3);
    assert.strictEqual(weightageAll.yearsRange, '2022–2024');
  });

  test('TEST 5: Question-type distribution is dynamic and differs across subjects and streams', () => {
    // Subject 1: Engineering Mathematics (2024)
    const mathPapers = pyqEngine.getPapersForSubject('Engineering Mathematics', 'all', '2024');
    const mathW = pyqEngine.calculateWeightage(mathPapers, 'all', '2024');

    // Subject 2: Operating Systems (2024)
    const osPapers = pyqEngine.getPapersForSubject('Operating Systems', 'all', '2024');
    const osW = pyqEngine.calculateWeightage(osPapers, 'all', '2024');

    // Subject 3: Human Anatomy & Physiology (Medical 2024)
    const medPapers = pyqEngine.getPapersForSubject('Human Anatomy & Physiology', 'all', '2024');
    const medW = pyqEngine.calculateWeightage(medPapers, 'all', '2024');

    // Subject 4: Financial Accounting (Commerce 2024)
    const comPapers = pyqEngine.getPapersForSubject('Financial Accounting', 'all', '2024');
    const comW = pyqEngine.calculateWeightage(comPapers, 'all', '2024');

    // Verify percentages are NOT all identical 25%, 25%, 50%
    const math2MPct = mathW.marksCategories.twoMarks.pct;
    const math5MPct = mathW.marksCategories.fiveMarks.pct;
    const math10MPct = mathW.marksCategories.tenMarks.pct;

    const os2MPct = osW.marksCategories.twoMarks.pct;
    const os5MPct = osW.marksCategories.fiveMarks.pct;
    const os10MPct = osW.marksCategories.tenMarks.pct;

    const med2MPct = medW.marksCategories.twoMarks.pct;
    const med5MPct = medW.marksCategories.fiveMarks.pct;
    const med10MPct = medW.marksCategories.tenMarks.pct;

    // Check that distributions are calculated and not identical across distinct subjects
    const isMathIdenticalToOs = (math2MPct === os2MPct && math5MPct === os5MPct && math10MPct === os10MPct);
    const isMathIdenticalToMed = (math2MPct === med2MPct && math5MPct === med5MPct && math10MPct === med10MPct);

    assert.ok(!isMathIdenticalToOs || !isMathIdenticalToMed, 'Marks distribution must differ across different subjects/curricula');

    // Check that percentages sum to approximately 100%
    const mathSum = math2MPct + math5MPct + math10MPct;
    assert.ok(Math.abs(mathSum - 100) < 1.0, `Math percentages sum should be ~100, got ${mathSum}`);

    const osSum = os2MPct + os5MPct + os10MPct;
    assert.ok(Math.abs(osSum - 100) < 1.0, `OS percentages sum should be ~100, got ${osSum}`);

    const medSum = med2MPct + med5MPct + med10MPct;
    assert.ok(Math.abs(medSum - 100) < 1.0, `Medical percentages sum should be ~100, got ${medSum}`);
  });

  test('TEST 6: Question-type distribution varies across examination years for the same subject', () => {
    const math2024 = pyqEngine.calculateWeightage(pyqEngine.getPapersForSubject('Engineering Mathematics', 'all', '2024'), 'all', '2024');
    const math2023 = pyqEngine.calculateWeightage(pyqEngine.getPapersForSubject('Engineering Mathematics', 'all', '2023'), 'all', '2023');

    const m24 = math2024.marksCategories;
    const m23 = math2023.marksCategories;

    // Math 2024 has 12M 2M questions (15%), Math 2023 has 20M 2M questions (25%)
    assert.notStrictEqual(m24.twoMarks.pct, m23.twoMarks.pct, '2024 and 2023 should reflect actual distinct paper patterns');
    assert.notStrictEqual(m24.twoMarks.marks, m23.twoMarks.marks);
  });

  test('TEST 7: Chapter weightage is strictly in syllabus order (Unit 1, Unit 2, Unit 3, ...)', () => {
    const papers = pyqEngine.getPapersForSubject('Engineering Mathematics', 'all', '2024');
    const weightage = pyqEngine.calculateWeightage(papers, 'all', '2024');

    const chList = weightage.chapterWeightage;
    assert.ok(chList.length > 0, 'Must have chapter weightage list');

    // Verify ordering by chapterNum
    for (let i = 0; i < chList.length - 1; i++) {
      const currentNum = chList[i].chapterNum;
      const nextNum = chList[i + 1].chapterNum;
      assert.ok(currentNum <= nextNum, `Chapters must be in syllabus order: Unit ${currentNum} should come before Unit ${nextNum}`);
    }

    // Verify each item has marks, pct, and title
    chList.forEach(item => {
      assert.ok(item.chapterTitle, 'Chapter must have title');
      assert.ok(typeof item.marks === 'number' && item.marks > 0, 'Chapter marks must be > 0');
      assert.ok(typeof item.pct === 'number' && item.pct > 0, 'Chapter pct must be > 0');
    });

    // Verify total marks across chapters matches total classified marks
    const sumMarks = chList.reduce((acc, c) => acc + c.marks, 0);
    assert.strictEqual(sumMarks, weightage.totalClassifiedMarks, 'Sum of chapter marks must match totalClassifiedMarks');
  });

  test('TEST 8: Filtering by a specific chapter isolates questions for that chapter', () => {
    const allChapters = pyqEngine.getChaptersForSubject('Engineering Mathematics');
    assert.ok(allChapters.length > 0, 'Should have chapters for Engineering Mathematics');

    const targetChapter = allChapters[0];
    const filteredPapers = pyqEngine.getPapersForSubject('Engineering Mathematics', targetChapter.id, '2024');
    assert.ok(filteredPapers.length > 0, 'Should have paper with questions for target chapter');

    const filteredWeightage = pyqEngine.calculateWeightage(filteredPapers, targetChapter.id, '2024');
    // Only target chapter should be in chapterWeightage
    assert.strictEqual(filteredWeightage.chapterWeightage.length, 1);
    assert.strictEqual(filteredWeightage.chapterWeightage[0].chapterId, targetChapter.id);
  });

  test('TEST 9: Operating Systems uses actual verified static questions mapped to syllabus units', () => {
    const osPapers = pyqEngine.getPapersForSubject('Operating Systems', 'all', '2024');
    assert.strictEqual(osPapers.length, 1);
    const osPaper = osPapers[0];

    // Check that sections were converted from real questions in pyq_mu_os_may24
    assert.ok(osPaper.sections.length > 0, 'Sections must exist');
    const allQuestions = osPaper.allQuestions;
    assert.ok(allQuestions.length > 0, 'Must have questions');

    // Verify questions have chapter assignments
    const hasMappedChapters = allQuestions.some(q => q.chapterId && q.chapterId.startsWith('ch_os_'));
    assert.ok(hasMappedChapters, 'Real OS questions should be mapped to ch_os_* units');

    // Verify weightage calculation works cleanly
    const osW = pyqEngine.calculateWeightage(osPapers, 'all', '2024');
    assert.strictEqual(osW.totalPaperMarks, 80);
    assert.ok(osW.chapterWeightage.length >= 4, 'Multiple syllabus units should receive weightage');
  });

  test('TEST 10: All 4 academic streams have working subjects and authentic weightage calculations', () => {
    const streams = ['engineering', 'medical', 'commerce', 'arts'];

    streams.forEach(stream => {
      const subjects = pyqEngine.getSubjectsForField(stream);
      assert.ok(subjects.length > 0, `Stream ${stream} must have subjects`);

      const sampleSubject = subjects[0];
      const years = pyqEngine.getAvailableExamYears(sampleSubject);
      assert.ok(years.length > 0, `Subject ${sampleSubject} must have available exam years`);

      const defaultYear = years[0];
      const papers = pyqEngine.getPapersForSubject(sampleSubject, 'all', defaultYear);
      assert.strictEqual(papers.length, 1, `Subject ${sampleSubject} should have 1 paper for default year ${defaultYear}`);

      const weightage = pyqEngine.calculateWeightage(papers, 'all', defaultYear);
      assert.strictEqual(weightage.isAggregate, false, 'Default year is not aggregate');
      assert.strictEqual(weightage.totalPaperMarks, 80, `Paper marks should be 80 M for ${sampleSubject}`);
      assert.ok(weightage.totalQuestions > 0, `Must have analyzed questions for ${sampleSubject}`);
      assert.ok(weightage.chapterWeightage.length > 0, `Must have chapter weightage for ${sampleSubject}`);
    });
  });

  test('TEST 11: code.html contains required ID hooks and dynamic functions', () => {
    const htmlPath = path.resolve(__dirname, '../EduPrep/previous_year_papers/code.html');
    const htmlContent = fs.readFileSync(htmlPath, 'utf8');

    // Verify required IDs exist
    assert.ok(htmlContent.includes('id="pyqAnalysisContextPill"'), 'Must have id="pyqAnalysisContextPill"');
    assert.ok(htmlContent.includes('id="labelTotalMarks"'), 'Must have id="labelTotalMarks"');
    assert.ok(htmlContent.includes('id="statTotalMarks"'), 'Must have id="statTotalMarks"');
    assert.ok(htmlContent.includes('id="statTotalQuestions"'), 'Must have id="statTotalQuestions"');
    assert.ok(htmlContent.includes('id="chapterWeightageContainer"'), 'Must have id="chapterWeightageContainer"');
    assert.ok(htmlContent.includes('id="filterYearSelect"'), 'Must have id="filterYearSelect"');

    // Verify JavaScript functions exist
    assert.ok(htmlContent.includes('function populateYearsForSubject('), 'Must define populateYearsForSubject');
    assert.ok(htmlContent.includes('escapeHtml('), 'Must define escapeHtml');
    assert.ok(htmlContent.includes('populateYearsForSubject(selectedPyqSubject)'), 'Must call populateYearsForSubject when subject changes');
    assert.ok(htmlContent.includes('Total Aggregate Marks'), 'Must support Total Aggregate Marks label');
    assert.ok(htmlContent.includes('Total Paper Marks'), 'Must support Total Paper Marks label');
  });

  test('TEST 12: Bookmark toggle functions correctly without modifying state unexpectedly', () => {
    const initialBookmarked = EduPrep.getState().progress.bookmarkedPapers || [];
    const testPaperId = 'pyq_mu_os_may24';

    // Toggle bookmark on
    const isSaved = EduPrep.toggleBookmark('paper', testPaperId);
    assert.strictEqual(typeof isSaved, 'boolean');

    const afterState = EduPrep.getState();
    if (isSaved) {
      assert.ok(afterState.progress.bookmarkedPapers.includes(testPaperId));
    }

    // Toggle back
    EduPrep.toggleBookmark('paper', testPaperId);
  });
});
